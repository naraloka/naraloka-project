# Naraloka (Book Platform) — Prototipe UI/UX

Prototipe platform e-book kerja sama penulis: Beranda, Katalog, Detail E-book, Reader (bookmark/highlight/catatan/offline simulasi), Portal Penulis, dan Dashboard Admin.

## Menjalankan Lokal

```bash
npm install
npm run dev
```

## Deploy Publik (Vercel)

1. Buat repository GitHub baru, lalu push project ini.
2. Buka Vercel → **New Project** → Import repo GitHub.
3. Pastikan pengaturan berikut:
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Klik **Deploy** → Vercel akan memberi URL publik.

Catatan:
- File [vercel.json](./vercel.json) sudah disiapkan agar routing React Router tetap berjalan saat refresh URL.

