import { useMemo, useState } from "react";
import { Crown, GraduationCap, Sparkles } from "lucide-react";
import Button from "@/components/Button";
import Badge from "@/components/Badge";
import PricingCard from "@/components/PricingCard";
import { useSessionStore } from "@/stores/sessionStore";
import type { MembershipPlan } from "@/types/domain";

export default function Subscription() {
  const user = useSessionStore((s) => s.user);
  const membershipPlan = user?.membershipPlan ?? "FREE";
  const setMembershipPlan = useSessionStore((s) => s.setMembershipPlan);
  const [autoRenew, setAutoRenew] = useState(true);

  const planLabel = useMemo(() => {
    if (membershipPlan === "PREMIUM") return "Premium";
    if (membershipPlan === "EDU") return "Edukasi";
    return "Gratis";
  }, [membershipPlan]);

  const choose = (plan: MembershipPlan) => {
    setMembershipPlan(plan);
  };

  return (
    <div className="space-y-8">
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-white px-3 py-2 text-xs font-medium text-muted">
              <Sparkles size={14} className="text-brand-2" />
              Membership Naraloka
            </div>
            <div className="mt-4 text-2xl font-semibold tracking-tight text-ink md:text-4xl">
              Pilih paket yang sesuai ritme bacamu
            </div>
            <div className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
              Premium untuk akses penuh + offline. Edukasi untuk konten belajar yang lebih terstruktur.
              Auto renewal dapat diaktifkan agar akses tidak terputus.
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-surface p-5">
            <div className="text-xs font-semibold text-muted">Paket aktif</div>
            <div className="mt-2 flex items-center gap-2">
              <Badge tone="brand">{planLabel}</Badge>
              {membershipPlan !== "FREE" ? (
                <Badge tone={autoRenew ? "success" : "neutral"}>
                  {autoRenew ? "Auto Renewal ON" : "Auto Renewal OFF"}
                </Badge>
              ) : null}
            </div>
            {membershipPlan !== "FREE" ? (
              <button
                type="button"
                className="mt-4 w-full rounded-2xl border border-border bg-white px-4 py-3 text-sm font-semibold text-ink transition hover:bg-surface"
                onClick={() => setAutoRenew((v) => !v)}
              >
                Toggle Auto Renewal
              </button>
            ) : null}
            <div className="mt-3 text-xs text-muted">
              Pembayaran langganan, gateway, dan notifikasi masih simulasi untuk prototipe.
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <PricingCard
          title="Gratis"
          priceLabel="Rp0"
          description="Untuk coba pengalaman membaca dan akses konten terbuka."
          features={[
            "Akses e-book gratis",
            "Bookmark halaman",
            "Wishlist & rekomendasi dasar",
          ]}
          onSelect={() => choose("FREE")}
        />
        <PricingCard
          title="Premium"
          priceLabel="Rp49.000/bulan"
          description="Akses konten Premium + offline download."
          features={[
            "Akses konten Premium",
            "Download offline",
            "Highlight & catatan",
            "Notifikasi promo & rilis terbaru",
          ]}
          highlight
          onSelect={() => choose("PREMIUM")}
        />
        <PricingCard
          title="Edukasi"
          priceLabel="Rp29.000/bulan"
          description="Konten edukasi yang ringkas dan progres belajar."
          features={[
            "Akses konten Edukasi",
            "Catatan terstruktur",
            "Progress belajar (simulasi)",
          ]}
          onSelect={() => choose("EDU")}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-border bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-ink">
            <Crown size={16} className="text-brand-2" /> Premium
          </div>
          <div className="mt-2 text-sm text-muted">
            Cocok untuk pembaca rutin, koleksi besar, dan kebutuhan offline.
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-ink">
            <GraduationCap size={16} className="text-brand-2" /> Edukasi
          </div>
          <div className="mt-2 text-sm text-muted">
            Cocok untuk belajar mandiri: catatan, highlight, dan progres yang konsisten.
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-white p-5">
          <div className="text-sm font-semibold text-ink">Metode pembayaran</div>
          <div className="mt-2 text-sm text-muted">
            QRIS, Transfer Bank, E-Wallet, Virtual Account, Kartu Kredit/Debit (rencana integrasi Midtrans/Xendit).
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-white p-6 text-center">
        <div className="text-sm font-semibold text-ink">Butuh bantuan?</div>
        <div className="mt-1 text-sm text-muted">
          Hubungi WhatsApp Customer Service atau email support.
        </div>
        <div className="mt-4 flex flex-col justify-center gap-2 sm:flex-row">
          <a href="https://wa.me/6280000000000" className="sm:w-auto">
            <Button variant="secondary" className="w-full">
              WhatsApp CS
            </Button>
          </a>
          <a href="mailto:support@naraloka.app" className="sm:w-auto">
            <Button variant="secondary" className="w-full">
              Email
            </Button>
          </a>
        </div>
      </div>
    </div>
  );
}

