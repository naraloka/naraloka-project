import { useMemo, useState } from "react";
import { CheckCircle2, CreditCard, QrCode, Wallet, Landmark } from "lucide-react";
import Button from "@/components/Button";
import Badge from "@/components/Badge";

type Method = "QRIS" | "TRANSFER" | "EWALLET" | "VA" | "CARD";

export default function Checkout() {
  const [method, setMethod] = useState<Method>("QRIS");
  const [paid, setPaid] = useState(false);

  const instructions = useMemo(() => {
    if (method === "QRIS") return "Scan QRIS menggunakan aplikasi bank atau e-wallet.";
    if (method === "TRANSFER")
      return "Transfer ke rekening virtual (BCA/BRI/BNI/Mandiri) sesuai instruksi.";
    if (method === "EWALLET") return "Pilih e-wallet (GoPay/OVO/DANA/ShopeePay/LinkAja).";
    if (method === "VA") return "Gunakan Virtual Account untuk pembayaran otomatis terverifikasi.";
    return "Masukkan kartu Visa/Mastercard untuk pembayaran.";
  }, [method]);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <div className="text-2xl font-semibold tracking-tight text-ink md:text-3xl">
          Checkout
        </div>
        <div className="mt-2 text-sm text-muted">
          Ini adalah simulasi UI pembayaran. Integrasi Midtrans/Xendit dapat ditambahkan pada fase backend.
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
        <div className="flex items-center justify-between gap-4">
          <div className="text-sm font-semibold text-ink">Status</div>
          {paid ? <Badge tone="success">PAID</Badge> : <Badge tone="warning">PENDING</Badge>}
        </div>

        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setMethod("QRIS")}
            className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
              method === "QRIS"
                ? "border-brand-2 bg-brand-2/10"
                : "border-border bg-white hover:bg-surface"
            }`}
          >
            <QrCode className={method === "QRIS" ? "text-brand-2" : "text-muted"} size={18} />
            <div>
              <div className="text-sm font-semibold text-ink">QRIS</div>
              <div className="text-xs text-muted">Cepat & universal</div>
            </div>
          </button>
          <button
            type="button"
            onClick={() => setMethod("TRANSFER")}
            className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
              method === "TRANSFER"
                ? "border-brand-2 bg-brand-2/10"
                : "border-border bg-white hover:bg-surface"
            }`}
          >
            <Landmark className={method === "TRANSFER" ? "text-brand-2" : "text-muted"} size={18} />
            <div>
              <div className="text-sm font-semibold text-ink">Transfer Bank</div>
              <div className="text-xs text-muted">BCA, BRI, BNI, Mandiri</div>
            </div>
          </button>
          <button
            type="button"
            onClick={() => setMethod("EWALLET")}
            className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
              method === "EWALLET"
                ? "border-brand-2 bg-brand-2/10"
                : "border-border bg-white hover:bg-surface"
            }`}
          >
            <Wallet className={method === "EWALLET" ? "text-brand-2" : "text-muted"} size={18} />
            <div>
              <div className="text-sm font-semibold text-ink">E-Wallet</div>
              <div className="text-xs text-muted">GoPay, OVO, DANA, ShopeePay, LinkAja</div>
            </div>
          </button>
          <button
            type="button"
            onClick={() => setMethod("CARD")}
            className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
              method === "CARD"
                ? "border-brand-2 bg-brand-2/10"
                : "border-border bg-white hover:bg-surface"
            }`}
          >
            <CreditCard className={method === "CARD" ? "text-brand-2" : "text-muted"} size={18} />
            <div>
              <div className="text-sm font-semibold text-ink">Kartu</div>
              <div className="text-xs text-muted">Visa & Mastercard</div>
            </div>
          </button>
        </div>

        <div className="mt-5 rounded-2xl border border-border bg-surface p-4 text-sm text-muted">
          {instructions}
        </div>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
          <Button variant="secondary" onClick={() => setPaid(false)} disabled={!paid}>
            Reset
          </Button>
          <Button
            onClick={() => setPaid(true)}
            disabled={paid}
          >
            <CheckCircle2 size={16} />
            Tandai Sukses
          </Button>
        </div>
      </div>
    </div>
  );
}

