import { useMemo, useState } from "react";
import { CheckCircle2, Copy, CreditCard, Landmark, LoaderCircle, Mail, MessageCircleMore, QrCode, ShieldCheck, Wallet } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import Button from "@/components/Button";
import Badge from "@/components/Badge";
import Input from "@/components/Input";
import {
  supportEmail,
  supportEmailUrl,
  supportWhatsAppDisplay,
  supportWhatsAppUrl,
} from "@/constants/contact";
import { startMidtransSnapPayment } from "@/lib/midtrans";
import { useSessionStore } from "@/stores/sessionStore";
import { useTransactionStore } from "@/stores/transactionStore";
import type { MembershipPlan, PaymentMethod } from "@/types/domain";
import { formatIdrFromCents } from "@/utils/format";

type Method = "QRIS" | "TRANSFER" | "EWALLET" | "VA" | "CARD";
type BankOption = "BCA" | "BRI" | "BNI" | "MANDIRI";
type WalletOption = "GOPAY" | "OVO" | "DANA" | "SHOPEEPAY" | "LINKAJA";
type PaymentState = "IDLE" | "PROCESSING" | "PENDING" | "SUCCESS" | "ERROR";

function toPaymentMethod(method: Method): PaymentMethod {
  if (method === "TRANSFER") return "BANK_TRANSFER";
  if (method === "EWALLET") return "E_WALLET";
  if (method === "VA") return "VIRTUAL_ACCOUNT";
  return method;
}

export default function Checkout() {
  const [searchParams] = useSearchParams();
  const user = useSessionStore((s) => s.user);
  const setMembershipPlan = useSessionStore((s) => s.setMembershipPlan);
  const upsertTransaction = useTransactionStore((s) => s.upsertTransaction);
  const updateTransactionStatus = useTransactionStore((s) => s.updateTransactionStatus);
  const [method, setMethod] = useState<Method>("QRIS");
  const [paymentState, setPaymentState] = useState<PaymentState>("IDLE");
  const [buyerName, setBuyerName] = useState(user?.name ?? "");
  const [buyerEmail, setBuyerEmail] = useState(user?.email ?? "");
  const [buyerWhatsApp, setBuyerWhatsApp] = useState("081234567890");
  const [selectedBank, setSelectedBank] = useState<BankOption>("BCA");
  const [selectedWallet, setSelectedWallet] = useState<WalletOption>("GOPAY");
  const [errorMessage, setErrorMessage] = useState("");
  const [statusMessage, setStatusMessage] = useState("");
  const [copied, setCopied] = useState(false);
  const [lastOrderId, setLastOrderId] = useState("");
  const [lastRedirectUrl, setLastRedirectUrl] = useState("");
  const selectedPlan = (searchParams.get("plan")?.toUpperCase() as MembershipPlan | null) ?? "PREMIUM";

  const checkoutProduct = useMemo(() => {
    if (selectedPlan === "EDU") {
      return {
        plan: "EDU" as MembershipPlan,
        label: "Langganan Naraloka Edukasi",
        amount: 29000,
        code: "NRL-EDU",
        itemId: "naraloka-edu",
      };
    }

    return {
      plan: "PREMIUM" as MembershipPlan,
      label: "Langganan Naraloka Premium",
      amount: 49000,
      code: "NRL-PREMIUM",
      itemId: "naraloka-premium",
    };
  }, [selectedPlan]);

  const amountLabel = formatIdrFromCents(checkoutProduct.amount * 100);

  const instructions = useMemo(() => {
    if (method === "QRIS") return "Pembayaran akan dibuka di popup Midtrans dengan opsi QRIS.";
    if (method === "TRANSFER") return `Pembayaran akan diarahkan ke Midtrans dengan preferensi transfer ${selectedBank}.`;
    if (method === "EWALLET")
      return `Pembayaran akan dibuka di Midtrans. Preferensi e-wallet kamu: ${selectedWallet}.`;
    if (method === "VA") return `Midtrans akan menampilkan Virtual Account dengan preferensi bank ${selectedBank}.`;
    return "Detail kartu akan diinput langsung di popup Midtrans, bukan di halaman ini.";
  }, [method, selectedBank, selectedWallet]);

  const statusTone = useMemo(() => {
    if (paymentState === "SUCCESS") return "success";
    if (paymentState === "PENDING") return "warning";
    if (paymentState === "ERROR") return "warning";
    if (paymentState === "PROCESSING") return "brand";
    return "neutral";
  }, [paymentState]);

  const statusLabel = useMemo(() => {
    if (paymentState === "SUCCESS") return "PAID";
    if (paymentState === "PENDING") return "PENDING";
    if (paymentState === "ERROR") return "FAILED";
    if (paymentState === "PROCESSING") return "PROCESSING";
    return "READY";
  }, [paymentState]);

  async function handleSubmitPayment() {
    if (!buyerName.trim() || !buyerEmail.trim() || !buyerWhatsApp.trim()) {
      setErrorMessage("Nama, email, dan nomor WhatsApp wajib diisi.");
      return;
    }
    if (!buyerEmail.includes("@")) {
      setErrorMessage("Format email belum valid.");
      return;
    }

    setErrorMessage("");
    setCopied(false);
    setPaymentState("PROCESSING");
    setStatusMessage("Membuat transaksi Midtrans...");

    try {
      const response = await fetch("/api/midtrans/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderCode: checkoutProduct.code,
          amount: checkoutProduct.amount,
          itemId: checkoutProduct.itemId,
          itemName: checkoutProduct.label,
          buyerName,
          buyerEmail,
          buyerWhatsApp,
          preferredMethod: method,
          preferredBank: selectedBank,
          preferredWallet: selectedWallet,
          finishUrl: `${window.location.origin}/checkout`,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.message || "Gagal membuat transaksi Midtrans.");
      }

      setLastOrderId(data.orderId || "");
      setLastRedirectUrl(data.redirectUrl || "");
      setStatusMessage("Popup Midtrans dibuka. Selesaikan pembayaran di sana.");
      upsertTransaction({
        orderId: data.orderId,
        itemLabel: checkoutProduct.label,
        amountCents: checkoutProduct.amount * 100,
        paymentMethod: toPaymentMethod(method),
        status: "PENDING",
        buyerEmail,
        buyerWhatsApp,
        redirectUrl: data.redirectUrl || "",
      });

      await startMidtransSnapPayment({
        token: data.token,
        clientKey: data.clientKey,
        environment: data.environment,
        callbacks: {
          onSuccess: () => {
            setMembershipPlan(checkoutProduct.plan);
            setPaymentState("SUCCESS");
            updateTransactionStatus(data.orderId, "SUCCESS", data.redirectUrl);
            setStatusMessage(
              `Pembayaran berhasil. Konfirmasi dikirim ke ${buyerEmail} dan WhatsApp ${buyerWhatsApp}.`
            );
          },
          onPending: () => {
            setPaymentState("PENDING");
            updateTransactionStatus(data.orderId, "PENDING", data.redirectUrl);
            setStatusMessage("Transaksi tercatat di Midtrans dan sedang menunggu penyelesaian pembayaran.");
          },
          onError: () => {
            setPaymentState("ERROR");
            updateTransactionStatus(data.orderId, "FAILED", data.redirectUrl);
            setErrorMessage("Midtrans mengembalikan status gagal. Coba ulangi atau gunakan metode lain.");
          },
          onClose: () => {
            setPaymentState((current) => (current === "PROCESSING" ? "IDLE" : current));
            setStatusMessage((current) =>
              current || "Popup Midtrans ditutup sebelum pembayaran selesai."
            );
          },
        },
      });
    } catch (error) {
      setPaymentState("ERROR");
      setErrorMessage(error instanceof Error ? error.message : "Gagal memulai pembayaran Midtrans.");
    }
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <div className="text-2xl font-semibold tracking-tight text-ink md:text-3xl">
          Checkout
        </div>
        <div className="mt-2 text-sm text-muted">
          Checkout aktif untuk paket {checkoutProduct.plan === "PREMIUM" ? "Premium" : "Edukasi"}.
        </div>
        <div className="mt-3">
          <Link to="/langganan" className="text-sm font-semibold text-brand hover:underline">
            Kembali ke pilihan paket
          </Link>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.25fr_0.85fr]">
        <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
          <div className="flex items-center justify-between gap-4">
            <div className="text-sm font-semibold text-ink">Status pembayaran</div>
            <Badge tone={statusTone}>{statusLabel}</Badge>
          </div>

          <div className="mt-6">
            <div className="text-sm font-semibold text-ink">Data pembeli</div>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <Input value={buyerName} onChange={(e) => setBuyerName(e.target.value)} placeholder="Nama lengkap" />
              <Input
                type="email"
                value={buyerEmail}
                onChange={(e) => setBuyerEmail(e.target.value)}
                placeholder="Email aktif"
              />
              <Input
                className="md:col-span-2"
                value={buyerWhatsApp}
                onChange={(e) => setBuyerWhatsApp(e.target.value)}
                placeholder="Nomor WhatsApp"
              />
            </div>
          </div>

          <div className="mt-6">
            <div className="text-sm font-semibold text-ink">Pilih metode pembayaran</div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setMethod("QRIS")}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
                  method === "QRIS"
                    ? "border-brand-2 bg-brand-2/10"
                    : "border-border bg-white hover:bg-surface"
                }`}
              >
                <QrCode className={method === "QRIS" ? "text-brand-2" : "text-muted"} size={18} />
                <div>
                  <div className="text-sm font-semibold text-ink">QRIS</div>
                  <div className="text-xs text-muted">Cepat & universal</div>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setMethod("TRANSFER")}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
                  method === "TRANSFER"
                    ? "border-brand-2 bg-brand-2/10"
                    : "border-border bg-white hover:bg-surface"
                }`}
              >
                <Landmark className={method === "TRANSFER" ? "text-brand-2" : "text-muted"} size={18} />
                <div>
                  <div className="text-sm font-semibold text-ink">Transfer Bank</div>
                  <div className="text-xs text-muted">BCA, BRI, BNI, Mandiri</div>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setMethod("EWALLET")}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
                  method === "EWALLET"
                    ? "border-brand-2 bg-brand-2/10"
                    : "border-border bg-white hover:bg-surface"
                }`}
              >
                <Wallet className={method === "EWALLET" ? "text-brand-2" : "text-muted"} size={18} />
                <div>
                  <div className="text-sm font-semibold text-ink">E-Wallet</div>
                  <div className="text-xs text-muted">GoPay, OVO, DANA, ShopeePay, LinkAja</div>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setMethod("VA")}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
                  method === "VA"
                    ? "border-brand-2 bg-brand-2/10"
                    : "border-border bg-white hover:bg-surface"
                }`}
              >
                <ShieldCheck className={method === "VA" ? "text-brand-2" : "text-muted"} size={18} />
                <div>
                  <div className="text-sm font-semibold text-ink">Virtual Account</div>
                  <div className="text-xs text-muted">Pembayaran otomatis terverifikasi</div>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setMethod("CARD")}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition sm:col-span-2 ${
                  method === "CARD"
                    ? "border-brand-2 bg-brand-2/10"
                    : "border-border bg-white hover:bg-surface"
                }`}
              >
                <CreditCard className={method === "CARD" ? "text-brand-2" : "text-muted"} size={18} />
                <div>
                  <div className="text-sm font-semibold text-ink">Kartu Kredit / Debit</div>
                  <div className="text-xs text-muted">Visa & Mastercard</div>
                </div>
              </button>
            </div>
          </div>

          <div className="mt-5 rounded-2xl border border-border bg-surface p-4 text-sm text-muted">
            {instructions}
          </div>

          {method === "TRANSFER" || method === "VA" ? (
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              <label className="grid gap-2 text-sm">
                <span className="font-semibold text-ink">Pilih bank</span>
                <select
                  className="h-10 rounded-xl border border-border bg-white px-3 text-sm font-medium text-ink outline-none"
                  value={selectedBank}
                  onChange={(e) => setSelectedBank(e.target.value as BankOption)}
                >
                  <option value="BCA">BCA</option>
                  <option value="BRI">BRI</option>
                  <option value="BNI">BNI</option>
                  <option value="MANDIRI">Mandiri</option>
                </select>
              </label>
            </div>
          ) : null}

          {method === "EWALLET" ? (
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              <label className="grid gap-2 text-sm">
                <span className="font-semibold text-ink">Pilih e-wallet</span>
                <select
                  className="h-10 rounded-xl border border-border bg-white px-3 text-sm font-medium text-ink outline-none"
                  value={selectedWallet}
                  onChange={(e) => setSelectedWallet(e.target.value as WalletOption)}
                >
                  <option value="GOPAY">GoPay</option>
                  <option value="OVO">OVO</option>
                  <option value="DANA">DANA</option>
                  <option value="SHOPEEPAY">ShopeePay</option>
                  <option value="LINKAJA">LinkAja</option>
                </select>
              </label>
              <Input value={buyerWhatsApp} onChange={(e) => setBuyerWhatsApp(e.target.value)} placeholder="Nomor terdaftar e-wallet" />
            </div>
          ) : null}

          {errorMessage ? (
            <div className="mt-5 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">
              {errorMessage}
            </div>
          ) : null}

          {statusMessage ? (
            <div className="mt-5 rounded-2xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-800">
              {statusMessage}
            </div>
          ) : null}

          {paymentState === "SUCCESS" ? (
            <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
              Pembayaran berhasil diproses. Bukti dan instruksi lanjutan dikirim ke {buyerEmail} dan
              konfirmasi ke WhatsApp {buyerWhatsApp}.
            </div>
          ) : null}

          <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
            <Button
              variant="secondary"
              onClick={() => {
                setPaymentState("IDLE");
                setErrorMessage("");
                setStatusMessage("");
                setCopied(false);
                setLastOrderId("");
                setLastRedirectUrl("");
              }}
              disabled={
                paymentState === "IDLE" &&
                !errorMessage &&
                !statusMessage &&
                !lastOrderId &&
                !lastRedirectUrl
              }
            >
              Reset
            </Button>
            <Button onClick={handleSubmitPayment} disabled={paymentState === "PROCESSING"}>
              {paymentState === "PROCESSING" ? <LoaderCircle size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
              Bayar via Midtrans
            </Button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="text-sm font-semibold text-ink">Ringkasan pesanan</div>
            <div className="mt-4 space-y-3 text-sm">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="font-semibold text-ink">{checkoutProduct.label}</div>
                  <div className="mt-1 text-xs text-muted">Kode referensi: {checkoutProduct.code}</div>
                </div>
                <div className="font-semibold text-ink">{amountLabel}</div>
              </div>
              <div className="flex items-center justify-between gap-4 text-muted">
                <span>Biaya layanan</span>
                <span>Rp0</span>
              </div>
              <div className="flex items-center justify-between gap-4 border-t border-border pt-3">
                <span className="font-semibold text-ink">Total</span>
                <span className="font-semibold text-ink">{amountLabel}</span>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="text-sm font-semibold text-ink">Detail transaksi Midtrans</div>
            <div className="mt-4 rounded-2xl border border-border bg-surface p-4">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-muted">
                {lastOrderId ? "Order ID" : "Status"}
              </div>
              <div className="mt-2 flex items-center justify-between gap-3">
                <div className="text-base font-semibold text-ink">
                  {lastOrderId || "Token transaksi akan dibuat saat klik bayar"}
                </div>
                <button
                  type="button"
                  disabled={!lastOrderId}
                  onClick={async () => {
                    try {
                      if (!lastOrderId) return;
                      await navigator.clipboard.writeText(lastOrderId);
                      setCopied(true);
                    } catch {
                      setCopied(false);
                    }
                  }}
                  className="inline-flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-xs font-semibold text-ink transition hover:bg-surface disabled:opacity-50"
                >
                  <Copy size={14} />
                  {copied ? "Tersalin" : "Salin"}
                </button>
              </div>
            </div>
            <div className="mt-4 text-xs leading-relaxed text-muted">
              Setelah transaksi dibuat, Snap Midtrans akan membuka popup pembayaran. Jika popup diblokir,
              kamu masih bisa lanjut lewat tautan redirect cadangan di bawah.
            </div>
            {lastRedirectUrl ? (
              <a
                href={lastRedirectUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex text-sm font-semibold text-brand hover:underline"
              >
                Buka halaman pembayaran Midtrans
              </a>
            ) : null}
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="text-sm font-semibold text-ink">Bantuan pembayaran</div>
            <div className="mt-2 text-sm text-muted">
              Jika ada kendala, hubungi tim Naraloka lewat WhatsApp atau email berikut.
            </div>
            <div className="mt-4 space-y-3">
              <a
                href={supportWhatsAppUrl}
                className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-surface px-4 py-3 transition hover:bg-white"
              >
                <div className="flex items-center gap-3">
                  <MessageCircleMore size={18} className="text-brand-2" />
                  <div>
                    <div className="text-sm font-semibold text-ink">WhatsApp CS</div>
                    <div className="text-xs text-muted">{supportWhatsAppDisplay}</div>
                  </div>
                </div>
                <span className="text-xs font-semibold text-brand">Hubungi</span>
              </a>
              <a
                href={supportEmailUrl}
                className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-surface px-4 py-3 transition hover:bg-white"
              >
                <div className="flex items-center gap-3">
                  <Mail size={18} className="text-brand-2" />
                  <div>
                    <div className="text-sm font-semibold text-ink">Email Support</div>
                    <div className="text-xs text-muted">{supportEmail}</div>
                  </div>
                </div>
                <span className="text-xs font-semibold text-brand">Kirim Email</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
