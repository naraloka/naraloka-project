import { ebooks as mockEbooks } from "@/data/mock";
import { getReviewSummaryForEbook } from "@/lib/reviews";
import { usePublishingStore } from "@/stores/publishingStore";

export function useCatalogEbooks() {
  const publishedEbooks = usePublishingStore((s) => s.publishedEbooks);
  const reviews = usePublishingStore((s) => s.reviews);
  const publishedIds = new Set(publishedEbooks.map((ebook) => ebook.id));
  return [...publishedEbooks, ...mockEbooks.filter((ebook) => !publishedIds.has(ebook.id))].map(
    (ebook) => {
      const summary = getReviewSummaryForEbook(ebook, reviews);
      return {
        ...ebook,
        ratingAvg: summary.ratingAvg,
        ratingCount: summary.ratingCount,
      };
    }
  );
}
