import { t2i } from "@/utils/image";
import { getReadableSupabaseError, supabase } from "@/lib/supabase";
import type {
  AuthorWorkspaceProfile,
  CollaborationRequest,
  CollaborationStatus,
  Manuscript,
  ManuscriptReviewDecision,
  ManuscriptReviewEntry,
  ManuscriptStatus,
  SuggestedMonetization,
} from "@/stores/publishingStore";
import type { BookAccess, BookCategory, Ebook, MembershipPlan, UserRole } from "@/types/domain";

type AuthorProfileRow = {
  user_id: string;
  display_name: string;
  bio: string | null;
  phone: string | null;
  portfolio_url: string | null;
  payout_account: string | null;
  specialty: string | null;
  updated_at: string | null;
};

type CollaborationRequestRow = {
  id: string;
  author_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  portfolio_url: string | null;
  pitch: string;
  status: string;
  sent_at: string | null;
};

type ManuscriptRow = {
  id: string;
  author_id: string;
  author_display_name: string | null;
  title: string;
  category: string;
  file_name: string;
  storage_bucket: string | null;
  storage_path: string | null;
  storage_mime_type: string | null;
  storage_size_bytes: number | null;
  storage_uploaded_at: string | null;
  submitted_at: string | null;
  status: string;
  admin_note: string | null;
  synopsis: string | null;
  target_audience: string | null;
  tags: unknown;
  word_count: number | null;
  price_cents: number | null;
  suggested_monetization: string | null;
  monetization_note: string | null;
  updated_at: string | null;
  published_ebook_id: string | null;
  published_at: string | null;
  published_access: string | null;
  published_required_plan: string | null;
  published_price_cents: number | null;
  published_is_featured: boolean | null;
  published_is_best_seller: boolean | null;
};

type AuthorWorkspaceSnapshot = {
  authorProfilesByUser: Record<string, AuthorWorkspaceProfile>;
  collaborationRequests: CollaborationRequest[];
  manuscripts: Manuscript[];
  reviewEntriesByManuscript: Record<string, ManuscriptReviewEntry[]>;
  publishedEbooks: Ebook[];
};

type ManuscriptReviewRow = {
  id: string;
  manuscript_id: string;
  reviewer_id: string;
  reviewer_name: string;
  decision: string;
  note: string;
  created_at: string | null;
};

function emptySnapshot(): AuthorWorkspaceSnapshot {
  return {
    authorProfilesByUser: {},
    collaborationRequests: [],
    manuscripts: [],
    reviewEntriesByManuscript: {},
    publishedEbooks: [],
  };
}

function normalizeBookCategory(value: unknown): BookCategory {
  if (
    value === "Novel" ||
    value === "Edukasi" ||
    value === "Motivasi" ||
    value === "Cerpen" ||
    value === "Komik Digital"
  ) {
    return value;
  }

  return "Novel";
}

function normalizeManuscriptStatus(value: unknown): ManuscriptStatus {
  if (
    value === "SUBMITTED" ||
    value === "IN_REVIEW" ||
    value === "NEEDS_REVISION" ||
    value === "IN_EDITING" ||
    value === "READY_TO_PUBLISH" ||
    value === "REJECTED" ||
    value === "APPROVED"
  ) {
    return value === "APPROVED" ? "READY_TO_PUBLISH" : value;
  }
  return "DRAFT";
}

function normalizeCollaborationStatus(value: unknown): CollaborationStatus {
  if (value === "REVIEWING" || value === "CONTACTED") return value;
  return "SENT";
}

function normalizeSuggestedMonetization(value: unknown): SuggestedMonetization | undefined {
  if (
    value === "FREE" ||
    value === "MEMBERSHIP_PREMIUM" ||
    value === "MEMBERSHIP_EDU" ||
    value === "PAID"
  ) {
    return value;
  }

  return undefined;
}

function normalizeBookAccess(value: unknown): BookAccess | undefined {
  if (value === "OPEN" || value === "MEMBERSHIP" || value === "PAID") return value;
  return undefined;
}

function normalizeMembershipPlan(value: unknown): MembershipPlan | undefined {
  if (value === "FREE" || value === "PREMIUM" || value === "EDU") return value;
  return undefined;
}

function normalizeReviewDecision(value: unknown): ManuscriptReviewDecision {
  if (
    value === "APPROVED" ||
    value === "REJECTED" ||
    value === "IN_REVIEW" ||
    value === "NEEDS_REVISION" ||
    value === "IN_EDITING" ||
    value === "READY_TO_PUBLISH"
  ) {
    return value === "APPROVED" ? "READY_TO_PUBLISH" : value;
  }
  return "COMMENT";
}

function ensureStringArray(value: unknown): string[] | undefined {
  if (!Array.isArray(value)) return undefined;
  const list = value.map((item) => String(item).trim()).filter(Boolean);
  return list.length ? list : undefined;
}

function nowIso() {
  return new Date().toISOString();
}

const authorManuscriptBucket =
  import.meta.env.VITE_SUPABASE_AUTHOR_MANUSCRIPT_BUCKET || "author-manuscripts";

function sanitizeFileName(name: string) {
  const [base, ...extParts] = name.trim().split(".");
  const safeBase = base.toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/-+/g, "-") || "manuscript";
  const safeExt = extParts.join(".").toLowerCase().replace(/[^a-z0-9.]+/g, "");
  return safeExt ? `${safeBase}.${safeExt}` : safeBase;
}

function getFileExtension(name: string) {
  const match = /\.([a-zA-Z0-9]+)$/.exec(name);
  return match?.[1]?.toLowerCase() || "";
}

function assertSupportedManuscriptFile(file: File) {
  const extension = getFileExtension(file.name);
  const allowedExtensions = new Set(["pdf", "docx"]);
  const allowedMimeTypes = new Set([
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ]);

  if (!allowedExtensions.has(extension) && !allowedMimeTypes.has(file.type)) {
    throw new Error("Format naskah harus PDF atau DOCX.");
  }

  const maxSizeBytes = 20 * 1024 * 1024;
  if (file.size > maxSizeBytes) {
    throw new Error("Ukuran file naskah maksimal 20MB.");
  }
}

function makePages(seedTitle: string, synopsis: string | undefined, pageCount: number) {
  const intro =
    synopsis?.trim() ||
    "Naskah ini telah dipublikasikan dari portal penulis Naraloka dan disiapkan untuk pengalaman membaca digital.";
  return Array.from({ length: pageCount }, (_, index) => {
    const pageNumber = index + 1;
    return (
      `${seedTitle}\n\nHalaman ${pageNumber}\n\n` +
      `${intro}\n\n` +
      "Versi digital ini dibuat untuk katalog Naraloka. Gunakan highlight, bookmark, dan perpustakaan untuk melanjutkan membaca kapan saja."
    );
  });
}

function manuscriptToPublishedEbook(manuscript: Manuscript, authorDisplayName?: string): Ebook | null {
  if (!manuscript.publishedAtISO || !manuscript.publishedAccess) return null;

  const pageCount = Math.max(12, Math.min(240, Math.round((manuscript.wordCount ?? 7200) / 300)));
  const title = manuscript.title.trim();
  const synopsis = manuscript.synopsis?.trim() || "Karya baru dari portal penulis Naraloka.";
  const coverPrompt = `Book cover for Indonesian ${manuscript.category.toLowerCase()} titled ${title}, author ${authorDisplayName || "Naraloka author"}, clean editorial composition, realistic printed cover, premium bookstore quality`;

  return {
    id: manuscript.publishedEbookId || `pub_${manuscript.id}`,
    title,
    authorId: manuscript.authorId,
    coverUrl: t2i(coverPrompt, "portrait_16_9"),
    category: manuscript.category,
    description: synopsis,
    ratingAvg: 0,
    ratingCount: 0,
    priceCents:
      manuscript.publishedAccess === "PAID"
        ? Math.max(0, manuscript.publishedPriceCents ?? manuscript.priceCents ?? 0)
        : 0,
    access: manuscript.publishedAccess,
    requiredPlan:
      manuscript.publishedAccess === "MEMBERSHIP" ? manuscript.publishedRequiredPlan : undefined,
    isBestSeller: Boolean(manuscript.publishedIsBestSeller),
    isFeatured: Boolean(manuscript.publishedIsFeatured),
    publishedAtISO: manuscript.publishedAtISO,
    pageCount,
    tags: manuscript.tags?.length ? manuscript.tags : [manuscript.category, "Karya Baru"],
    previewPages: makePages(title, synopsis, Math.min(3, pageCount)),
    pages: makePages(title, synopsis, pageCount),
  };
}

function mapAuthorProfileRow(row: AuthorProfileRow): AuthorWorkspaceProfile {
  return {
    userId: row.user_id,
    displayName: row.display_name,
    bio: row.bio || "",
    phone: row.phone || "",
    portfolioUrl: row.portfolio_url || "",
    payoutAccount: row.payout_account || "",
    specialty: row.specialty || "",
    updatedAtISO: row.updated_at || nowIso(),
  };
}

function mapCollaborationRequestRow(row: CollaborationRequestRow): CollaborationRequest {
  return {
    id: row.id,
    authorId: row.author_id,
    fullName: row.full_name,
    email: row.email,
    phone: row.phone || "",
    portfolioUrl: row.portfolio_url || "",
    pitch: row.pitch,
    status: normalizeCollaborationStatus(row.status),
    sentAtISO: row.sent_at || nowIso(),
  };
}

function mapReviewEntryRow(row: ManuscriptReviewRow): ManuscriptReviewEntry {
  return {
    id: row.id,
    manuscriptId: row.manuscript_id,
    reviewerId: row.reviewer_id,
    reviewerName: row.reviewer_name,
    decision: normalizeReviewDecision(row.decision),
    note: row.note,
    createdAtISO: row.created_at || nowIso(),
  };
}

function mapManuscriptRow(row: ManuscriptRow): Manuscript {
  return {
    id: row.id,
    authorId: row.author_id,
    title: row.title,
    authorDisplayName: row.author_display_name || undefined,
    category: normalizeBookCategory(row.category),
    fileName: row.file_name,
    storageBucket: row.storage_bucket || undefined,
    storagePath: row.storage_path || undefined,
    storageMimeType: row.storage_mime_type || undefined,
    storageSizeBytes: row.storage_size_bytes ?? undefined,
    storageUploadedAtISO: row.storage_uploaded_at || undefined,
    submittedAtISO: row.submitted_at || nowIso(),
    status: normalizeManuscriptStatus(row.status),
    adminNote: row.admin_note || undefined,
    synopsis: row.synopsis || undefined,
    targetAudience: row.target_audience || undefined,
    tags: ensureStringArray(row.tags),
    wordCount: row.word_count ?? undefined,
    priceCents: row.price_cents ?? undefined,
    suggestedMonetization: normalizeSuggestedMonetization(row.suggested_monetization),
    monetizationNote: row.monetization_note || undefined,
    updatedAtISO: row.updated_at || undefined,
    publishedEbookId: row.published_ebook_id || undefined,
    publishedAtISO: row.published_at || undefined,
    publishedAccess: normalizeBookAccess(row.published_access),
    publishedRequiredPlan: normalizeMembershipPlan(row.published_required_plan),
    publishedPriceCents: row.published_price_cents ?? undefined,
    publishedIsFeatured: Boolean(row.published_is_featured),
    publishedIsBestSeller: Boolean(row.published_is_best_seller),
  };
}

function reportWorkspaceError(action: string, error: unknown) {
  const message = error instanceof Error ? error.message : String(error || "unknown error");
  console.error(`[author-workspace] ${action}: ${message}`);
}

export async function fetchAuthorWorkspaceSnapshot(params: {
  userId: string;
  role: UserRole;
}) {
  if (!supabase || !params.userId.trim()) {
    return { error: "", data: emptySnapshot() };
  }

  const isAdmin = params.role === "ADMIN";
  const [profilesResult, publishedResult, manuscriptResult, collaborationResult, reviewResult] = await Promise.all([
    (isAdmin
      ? supabase!
          .from("author_workspace_profiles")
          .select("user_id,display_name,bio,phone,portfolio_url,payout_account,specialty,updated_at")
      : supabase!
          .from("author_workspace_profiles")
          .select("user_id,display_name,bio,phone,portfolio_url,payout_account,specialty,updated_at")
          .eq("user_id", params.userId)),
    supabase!
      .from("author_manuscripts")
      .select(
        "id,author_id,author_display_name,title,category,file_name,storage_bucket,storage_path,storage_mime_type,storage_size_bytes,storage_uploaded_at,submitted_at,status,admin_note,synopsis,target_audience,tags,word_count,price_cents,suggested_monetization,monetization_note,updated_at,published_ebook_id,published_at,published_access,published_required_plan,published_price_cents,published_is_featured,published_is_best_seller"
      )
      .not("published_at", "is", null),
    (isAdmin
      ? supabase!.from("author_manuscripts").select(
          "id,author_id,author_display_name,title,category,file_name,storage_bucket,storage_path,storage_mime_type,storage_size_bytes,storage_uploaded_at,submitted_at,status,admin_note,synopsis,target_audience,tags,word_count,price_cents,suggested_monetization,monetization_note,updated_at,published_ebook_id,published_at,published_access,published_required_plan,published_price_cents,published_is_featured,published_is_best_seller"
        )
      : supabase!
          .from("author_manuscripts")
          .select(
            "id,author_id,author_display_name,title,category,file_name,storage_bucket,storage_path,storage_mime_type,storage_size_bytes,storage_uploaded_at,submitted_at,status,admin_note,synopsis,target_audience,tags,word_count,price_cents,suggested_monetization,monetization_note,updated_at,published_ebook_id,published_at,published_access,published_required_plan,published_price_cents,published_is_featured,published_is_best_seller"
          )
          .eq("author_id", params.userId)),
    (isAdmin
      ? supabase!
          .from("author_collaboration_requests")
          .select("id,author_id,full_name,email,phone,portfolio_url,pitch,status,sent_at")
      : supabase!
          .from("author_collaboration_requests")
          .select("id,author_id,full_name,email,phone,portfolio_url,pitch,status,sent_at")
          .eq("author_id", params.userId)),
    supabase!
      .from("author_manuscript_reviews")
      .select("id,manuscript_id,reviewer_id,reviewer_name,decision,note,created_at")
      .order("created_at", { ascending: false }),
  ]);

  const firstError =
    profilesResult.error ||
    publishedResult.error ||
    manuscriptResult.error ||
    collaborationResult.error ||
    reviewResult.error;

  if (firstError) {
    return {
      error: getReadableSupabaseError(firstError.message),
      data: emptySnapshot(),
    };
  }

  const authorProfilesByUser = Object.fromEntries(
    ((profilesResult.data ?? []) as AuthorProfileRow[]).map((row) => {
      const profile = mapAuthorProfileRow(row);
      return [profile.userId, profile];
    })
  );

  const mergedManuscripts = new Map<string, Manuscript>();
  for (const row of (publishedResult.data ?? []) as ManuscriptRow[]) {
    const manuscript = mapManuscriptRow(row);
    mergedManuscripts.set(manuscript.id, manuscript);
  }
  for (const row of (manuscriptResult.data ?? []) as ManuscriptRow[]) {
    const manuscript = mapManuscriptRow(row);
    mergedManuscripts.set(manuscript.id, manuscript);
  }

  const manuscripts = [...mergedManuscripts.values()].sort(
    (a, b) =>
      +new Date(b.updatedAtISO ?? b.submittedAtISO) - +new Date(a.updatedAtISO ?? a.submittedAtISO)
  );
  const collaborationRequests = ((collaborationResult.data ?? []) as CollaborationRequestRow[])
    .map(mapCollaborationRequestRow)
    .sort((a, b) => +new Date(b.sentAtISO) - +new Date(a.sentAtISO));
  const reviewEntriesByManuscript = ((reviewResult.data ?? []) as ManuscriptReviewRow[]).reduce<
    Record<string, ManuscriptReviewEntry[]>
  >((acc, row) => {
    const entry = mapReviewEntryRow(row);
    acc[entry.manuscriptId] = [...(acc[entry.manuscriptId] ?? []), entry].sort(
      (a, b) => +new Date(b.createdAtISO) - +new Date(a.createdAtISO)
    );
    return acc;
  }, {});
  const publishedEbooks = manuscripts
    .map((manuscript) =>
      manuscriptToPublishedEbook(
        manuscript,
        manuscript.authorDisplayName || authorProfilesByUser[manuscript.authorId]?.displayName
      )
    )
    .filter((ebook): ebook is Ebook => Boolean(ebook));

  return {
    error: "",
    data: {
      authorProfilesByUser,
      collaborationRequests,
      manuscripts,
      reviewEntriesByManuscript,
      publishedEbooks,
    },
  };
}

export async function persistAuthorProfile(profile: Omit<AuthorWorkspaceProfile, "updatedAtISO"> | AuthorWorkspaceProfile) {
  if (!supabase || !profile.userId.trim()) return;

  const { error } = await supabase!.from("author_workspace_profiles").upsert(
    {
      user_id: profile.userId,
      display_name: profile.displayName,
      bio: profile.bio,
      phone: profile.phone,
      portfolio_url: profile.portfolioUrl,
      payout_account: profile.payoutAccount,
      specialty: profile.specialty,
      updated_at: nowIso(),
    },
    { onConflict: "user_id", ignoreDuplicates: false }
  );

  if (error) throw error;
}

export async function createCollaborationRequest(
  input: Omit<CollaborationRequest, "sentAtISO" | "status">
) {
  if (!supabase || !input.authorId.trim()) return;

  const { error } = await supabase!.from("author_collaboration_requests").insert({
    id: input.id,
    author_id: input.authorId,
    full_name: input.fullName,
    email: input.email,
    phone: input.phone,
    portfolio_url: input.portfolioUrl,
    pitch: input.pitch,
    status: "SENT",
    sent_at: nowIso(),
  });

  if (error) throw error;
}

export async function uploadAuthorManuscriptFile(params: {
  userId: string;
  manuscriptId?: string;
  file: File;
}) {
  if (!supabase || !params.userId.trim()) {
    throw new Error("Supabase belum terhubung untuk upload naskah.");
  }

  assertSupportedManuscriptFile(params.file);

  const manuscriptId = params.manuscriptId || crypto.randomUUID();
  const fileName = sanitizeFileName(params.file.name);
  const storagePath = `${params.userId}/${manuscriptId}/${Date.now()}-${fileName}`;
  const { error } = await supabase.storage
    .from(authorManuscriptBucket)
    .upload(storagePath, params.file, {
      upsert: false,
      contentType: params.file.type || undefined,
      cacheControl: "3600",
    });

  if (error) {
    throw new Error(getReadableSupabaseError(error.message));
  }

  return {
    manuscriptId,
    fileName: params.file.name,
    storageBucket: authorManuscriptBucket,
    storagePath,
    storageMimeType: params.file.type || undefined,
    storageSizeBytes: params.file.size,
    storageUploadedAtISO: nowIso(),
  };
}

export async function getAuthorManuscriptSignedUrl(params: {
  storageBucket?: string;
  storagePath?: string;
  fileName?: string;
  download?: boolean;
  expiresInSeconds?: number;
}) {
  if (!supabase) {
    throw new Error("Supabase belum terhubung untuk membuka file naskah.");
  }

  const storageBucket = params.storageBucket || authorManuscriptBucket;
  const storagePath = String(params.storagePath || "").trim();
  if (!storagePath) {
    throw new Error("File naskah belum tersedia di storage.");
  }

  const { data, error } = await supabase.storage.from(storageBucket).createSignedUrl(storagePath, params.expiresInSeconds ?? 300, {
    download: params.download ? params.fileName || "manuscript" : undefined,
  });

  if (error || !data?.signedUrl) {
    throw new Error(getReadableSupabaseError(error?.message || "Gagal membuat tautan file naskah."));
  }

  return data.signedUrl;
}

export async function persistManuscriptReviewEntry(entry: ManuscriptReviewEntry) {
  if (!supabase || !entry.manuscriptId.trim() || !entry.id.trim()) return;

  const { error } = await supabase.from("author_manuscript_reviews").insert({
    id: entry.id,
    manuscript_id: entry.manuscriptId,
    reviewer_id: entry.reviewerId,
    reviewer_name: entry.reviewerName,
    decision: entry.decision,
    note: entry.note,
    created_at: entry.createdAtISO,
  });

  if (error) throw error;
}

function manuscriptToRow(input: Manuscript) {
  return {
    id: input.id,
    author_id: input.authorId,
    author_display_name: input.authorDisplayName ?? null,
    title: input.title,
    category: input.category,
    file_name: input.fileName,
    storage_bucket: input.storageBucket ?? null,
    storage_path: input.storagePath ?? null,
    storage_mime_type: input.storageMimeType ?? null,
    storage_size_bytes: input.storageSizeBytes ?? null,
    storage_uploaded_at: input.storageUploadedAtISO ?? null,
    submitted_at: input.submittedAtISO,
    status: input.status,
    admin_note: input.adminNote ?? null,
    synopsis: input.synopsis ?? null,
    target_audience: input.targetAudience ?? null,
    tags: input.tags ?? [],
    word_count: input.wordCount ?? null,
    price_cents: input.priceCents ?? null,
    suggested_monetization: input.suggestedMonetization ?? null,
    monetization_note: input.monetizationNote ?? null,
    updated_at: input.updatedAtISO ?? nowIso(),
    published_ebook_id: input.publishedEbookId ?? null,
    published_at: input.publishedAtISO ?? null,
    published_access: input.publishedAccess ?? null,
    published_required_plan: input.publishedRequiredPlan ?? null,
    published_price_cents: input.publishedPriceCents ?? null,
    published_is_featured: input.publishedIsFeatured ?? false,
    published_is_best_seller: input.publishedIsBestSeller ?? false,
  };
}

export async function persistManuscript(manuscript: Manuscript) {
  if (!supabase || !manuscript.authorId.trim() || !manuscript.id.trim()) return;

  const { error } = await supabase!
    .from("author_manuscripts")
    .upsert(manuscriptToRow(manuscript), {
      onConflict: "id",
      ignoreDuplicates: false,
    });

  if (error) throw error;
}

export function reportAuthorWorkspaceSyncError(action: string, error: unknown) {
  reportWorkspaceError(action, error);
}
