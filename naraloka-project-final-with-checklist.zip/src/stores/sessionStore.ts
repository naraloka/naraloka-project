import { create } from "zustand";
import type { User } from "@supabase/supabase-js";
import type { MembershipPlan, UserProfile, UserRole } from "@/types/domain";
import { getAppUrl } from "@/lib/appUrl";
import { fetchMembershipRoyaltyLedgerSnapshot } from "@/lib/membershipRoyaltyLedger";
import { syncLedgerStateForUser } from "@/lib/paymentLedger";
import { fetchRoyaltyLedgerSnapshot } from "@/lib/royaltyLedger";
import { fetchPayoutSlipArchiveSnapshot } from "@/lib/payoutSlipArchive";
import { fetchReaderStateForUser } from "@/lib/readerState";
import { fetchAuthorWorkspaceSnapshot } from "@/lib/authorWorkspace";
import { useLibraryStore } from "@/stores/libraryStore";
import { usePublishingStore } from "@/stores/publishingStore";
import { getReadableSupabaseError, getSupabaseUserProfile, isSupabaseConfigured, supabase } from "@/lib/supabase";

type SelectableRole = Extract<UserRole, "READER" | "AUTHOR">;

const pendingRoleStorageKey = "naraloka_pending_signup_role";
const accountModeStorageKey = "naraloka_account_mode";

function normalizeSelectableRole(value: unknown): SelectableRole {
  return value === "AUTHOR" ? "AUTHOR" : "READER";
}

function setPendingSignupRole(role: SelectableRole) {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(pendingRoleStorageKey, role);
}

function getStoredAccountMode(userId: string, fallback: SelectableRole): SelectableRole {
  if (typeof window === "undefined" || !userId) return fallback;
  const value = window.localStorage.getItem(`${accountModeStorageKey}:${userId}`);
  return value === "AUTHOR" ? "AUTHOR" : value === "READER" ? "READER" : fallback;
}

function setStoredAccountMode(userId: string, role: SelectableRole) {
  if (typeof window === "undefined" || !userId) return;
  window.localStorage.setItem(`${accountModeStorageKey}:${userId}`, role);
}

function takePendingSignupRole(): SelectableRole | null {
  if (typeof window === "undefined") return null;
  const value = window.sessionStorage.getItem(pendingRoleStorageKey);
  if (value === "READER" || value === "AUTHOR") {
    window.sessionStorage.removeItem(pendingRoleStorageKey);
    return value;
  }
  return null;
}

async function syncPendingOAuthRole(user: User | null) {
  if (!user || !supabase) return user;
  const pendingRole = takePendingSignupRole();
  if (!pendingRole) return user;
  if (user.user_metadata?.role === "READER" || user.user_metadata?.role === "AUTHOR") return user;

  const { data, error } = await supabase.auth.updateUser({
    data: {
      ...user.user_metadata,
      role: pendingRole,
      membership_plan: user.user_metadata?.membership_plan ?? ("FREE" satisfies MembershipPlan),
    },
  });

  if (error) return user;
  return data.user ?? user;
}

async function getUserProfileWithLedger(user: User | null) {
  if (!user) return null;

  const profile = getSupabaseUserProfile(user);
  const trustedMembershipFallback =
    user.app_metadata?.membership_plan === "PREMIUM" || user.app_metadata?.membership_plan === "EDU"
      ? user.app_metadata.membership_plan
      : "FREE";
  const [
    ledgerSync,
    readerSync,
    authorWorkspaceSync,
    royaltyLedgerSync,
    membershipRoyaltySync,
    payoutSlipArchiveSync,
  ] = await Promise.all([
    syncLedgerStateForUser(profile.id, trustedMembershipFallback),
    fetchReaderStateForUser(profile.id),
    fetchAuthorWorkspaceSnapshot({ userId: profile.id, role: profile.role }),
    fetchRoyaltyLedgerSnapshot({ userId: profile.id, role: profile.role }),
    fetchMembershipRoyaltyLedgerSnapshot({ userId: profile.id, role: profile.role }),
    fetchPayoutSlipArchiveSnapshot({ userId: profile.id, role: profile.role }),
  ]);

  if (!readerSync.error) {
    useLibraryStore.getState().hydrateReaderState(profile.id, readerSync.data);
  }
  if (!authorWorkspaceSync.error) {
    usePublishingStore.getState().hydrateWorkspaceData(authorWorkspaceSync.data);
  }
  if (!royaltyLedgerSync.error) {
    usePublishingStore.getState().hydrateRoyaltyLedger(royaltyLedgerSync.data);
  }
  if (!membershipRoyaltySync.error) {
    usePublishingStore.getState().hydrateMembershipRoyaltyLedger(membershipRoyaltySync.data);
  }
  if (!payoutSlipArchiveSync.error) {
    usePublishingStore.getState().hydratePayoutSlipArchives(payoutSlipArchiveSync.data);
  }

  const syncErrors = [
    ledgerSync.error,
    readerSync.error,
    authorWorkspaceSync.error,
    royaltyLedgerSync.error,
    membershipRoyaltySync.error,
    payoutSlipArchiveSync.error,
  ]
    .filter(Boolean)
    .join(" ");
  return {
    user: {
      ...profile,
      membershipPlan: ledgerSync.membershipPlan,
    },
    ledgerError: syncErrors,
  };
}

type SessionState = {
  user: UserProfile | null;
  accountMode: SelectableRole;
  authReady: boolean;
  authError: string;
  initializeAuth: () => Promise<void>;
  signInWithPassword: (input: { email: string; password: string }) => Promise<{ error: string }>;
  signUpWithPassword: (input: { name: string; email: string; password: string; role: SelectableRole }) => Promise<{
    error: string;
    requiresEmailConfirmation: boolean;
  }>;
  signInWithGoogle: (input?: { role?: SelectableRole }) => Promise<{ error: string }>;
  logout: () => Promise<void>;
  setUserRole: (role: SelectableRole) => Promise<{ error: string }>;
  setAccountMode: (role: SelectableRole) => void;
  setMembershipPlan: (plan: MembershipPlan, expectedUserId?: string) => Promise<{ error: string }>;
  refreshCurrentUserSession: () => Promise<{ error: string }>;
};

let authInitialized = false;

export const useSessionStore = create<SessionState>()((set, get) => ({
  user: null,
  accountMode: "READER",
  authReady: false,
  authError: "",

  initializeAuth: async () => {
    if (!isSupabaseConfigured || !supabase) {
      set({
        user: null,
        authReady: true,
        authError: "Konfigurasi Supabase belum diisi. Tambahkan VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY.",
      });
      return;
    }

    if (!authInitialized) {
      authInitialized = true;
      supabase.auth.onAuthStateChange((_event, session) => {
        void (async () => {
          const syncedUser = await syncPendingOAuthRole(session?.user ?? null);
          const profileResult = await getUserProfileWithLedger(syncedUser);
          const nextUser = profileResult?.user ?? null;
          set({
            user: nextUser,
            accountMode: nextUser
              ? getStoredAccountMode(nextUser.id, normalizeSelectableRole(nextUser.role))
              : "READER",
            authReady: true,
            authError: profileResult?.ledgerError ?? "",
          });
        })();
      });
    }

    const { data, error } = await supabase.auth.getSession();
    const syncedUser = await syncPendingOAuthRole(data.session?.user ?? null);
    const profileResult = await getUserProfileWithLedger(syncedUser);
    const nextUser = profileResult?.user ?? null;
    set({
      user: nextUser,
      accountMode: nextUser
        ? getStoredAccountMode(nextUser.id, normalizeSelectableRole(nextUser.role))
        : "READER",
      authReady: true,
      authError: error
        ? getReadableSupabaseError(error.message)
        : profileResult?.ledgerError ?? "",
    });
  },

  signInWithPassword: async ({ email, password }) => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi." };
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    return { error: error ? getReadableSupabaseError(error.message) : "" };
  },

  signUpWithPassword: async ({ name, email, password, role }) => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi.", requiresEmailConfirmation: false };
    }

    const normalizedRole = normalizeSelectableRole(role);
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        emailRedirectTo: getAppUrl("/login"),
        data: {
          full_name: name.trim(),
          role: normalizedRole satisfies UserRole,
          membership_plan: "FREE" satisfies MembershipPlan,
        },
      },
    });

    return {
      error: error ? getReadableSupabaseError(error.message) : "",
      requiresEmailConfirmation: !error && !data.session,
    };
  },

  signInWithGoogle: async (input) => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi." };
    }

    if (input?.role) setPendingSignupRole(normalizeSelectableRole(input.role));
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: getAppUrl("/login"),
        queryParams: {
          prompt: "select_account",
        },
      },
    });

    return { error: error ? getReadableSupabaseError(error.message) : "" };
  },

  logout: async () => {
    if (!supabase) {
      set({ user: null, accountMode: "READER" });
      return;
    }

    await supabase.auth.signOut();
    set({ user: null, accountMode: "READER" });
  },

  setUserRole: async (role) => {
    const currentUser = get().user;
    if (!currentUser) {
      return { error: "Kamu harus login dulu." };
    }

    const normalizedRole = normalizeSelectableRole(role);
    setStoredAccountMode(currentUser.id, normalizedRole);
    set({ accountMode: normalizedRole });
    return { error: "" };
  },

  setAccountMode: (role) => {
    const currentUser = get().user;
    if (!currentUser) return;
    const normalizedRole = normalizeSelectableRole(role);
    setStoredAccountMode(currentUser.id, normalizedRole);
    set({ accountMode: normalizedRole });
  },

  setMembershipPlan: async (plan, expectedUserId) => {
    void plan;
    void expectedUserId;
    return {
      error:
        "Perubahan membership plan tidak boleh dilakukan langsung dari client. Gunakan checkout agar paket aktif berasal dari ledger pembayaran.",
    };
  },

  refreshCurrentUserSession: async () => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi." };
    }

    const { data, error } = await supabase.auth.getUser();
    if (error) {
      return { error: getReadableSupabaseError(error.message) };
    }

    const profileResult = await getUserProfileWithLedger(data.user ?? null);
    const nextUser = profileResult?.user ?? null;
    set({
      user: nextUser,
      accountMode: nextUser
        ? getStoredAccountMode(nextUser.id, normalizeSelectableRole(nextUser.role))
        : "READER",
      authReady: true,
      authError: profileResult?.ledgerError ?? "",
    });

    return { error: profileResult?.ledgerError ?? "" };
  },
}));
