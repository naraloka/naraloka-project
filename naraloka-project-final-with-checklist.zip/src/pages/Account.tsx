import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bookmark, CreditCard, Heart, LogOut, Mail, PenSquare, Shield, UserRound } from "lucide-react";
import Badge from "@/components/Badge";
import Button from "@/components/Button";
import { useSessionStore } from "@/stores/sessionStore";

export default function Account() {
  const navigate = useNavigate();
  const user = useSessionStore((s) => s.user);
  const accountMode = useSessionStore((s) => s.accountMode);
  const logout = useSessionStore((s) => s.logout);
  const setUserRole = useSessionStore((s) => s.setUserRole);
  const [roleMessage, setRoleMessage] = useState("");
  const [roleLoading, setRoleLoading] = useState(false);

  if (!user) return null;

  const roleLabel =
    user.role === "ADMIN" ? "Admin" : accountMode === "AUTHOR" ? "Penulis" : "Pembaca";
  const planLabel =
    user.membershipPlan === "PREMIUM"
      ? "Premium"
      : user.membershipPlan === "EDU"
        ? "Edukasi"
        : "Gratis";

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-brand-2/10 text-2xl font-semibold text-brand-2">
              {user.name.slice(0, 1).toUpperCase()}
            </div>
            <div>
              <div className="text-2xl font-semibold tracking-tight text-ink">{user.name}</div>
              <div className="mt-1 text-sm text-muted">{user.email}</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge tone="brand">{roleLabel}</Badge>
            <Badge tone={user.membershipPlan === "FREE" ? "neutral" : "success"}>{planLabel}</Badge>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-border bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-ink">
            <UserRound size={16} className="text-brand-2" />
            Profil
          </div>
          <div className="mt-3 text-sm text-muted">Nama akun, email, dan status pengguna yang sedang login.</div>
        </div>
        <div className="rounded-2xl border border-border bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-ink">
            <CreditCard size={16} className="text-brand-2" />
            Membership
          </div>
          <div className="mt-3 text-sm text-muted">
            Paket aktif kamu saat ini adalah <span className="font-semibold text-ink">{planLabel}</span>.
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-ink">
            <Shield size={16} className="text-brand-2" />
            Status Login
          </div>
          <div className="mt-3 text-sm text-muted">
            Sesi login tersimpan aman melalui Supabase Auth di browser pengguna.
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-white p-6">
        <div className="text-sm font-semibold text-ink">Mode akun</div>
        <div className="mt-2 text-sm text-muted">
          Kamu bisa memilih mode <span className="font-semibold text-ink">Pembaca</span> atau{" "}
          <span className="font-semibold text-ink">Penulis</span>. Role admin tetap diatur manual.
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={async () => {
              setRoleLoading(true);
              const result = await setUserRole("READER");
              setRoleLoading(false);
              setRoleMessage(result.error || "Mode akun diubah ke Pembaca.");
            }}
            className={`rounded-2xl border px-4 py-4 text-left transition ${
              accountMode === "READER" ? "border-brand-2 bg-brand-2/10" : "border-border bg-white hover:bg-surface"
            }`}
            disabled={roleLoading}
          >
            <div className="text-sm font-semibold text-ink">Pembaca</div>
            <div className="mt-1 text-xs text-muted">Fokus membaca, wishlist, bookmark, perpustakaan, dan langganan.</div>
          </button>
          <button
            type="button"
            onClick={async () => {
              setRoleLoading(true);
              const result = await setUserRole("AUTHOR");
              setRoleLoading(false);
              setRoleMessage(result.error || "Mode akun diubah ke Penulis.");
            }}
            className={`rounded-2xl border px-4 py-4 text-left transition ${
              accountMode === "AUTHOR" ? "border-brand-2 bg-brand-2/10" : "border-border bg-white hover:bg-surface"
            }`}
            disabled={roleLoading}
          >
            <div className="text-sm font-semibold text-ink">Penulis</div>
            <div className="mt-1 text-xs text-muted">Buka portal penulis untuk kerja sama, upload naskah, dan dashboard simulasi.</div>
          </button>
        </div>
        {roleMessage ? <div className="mt-4 text-sm text-muted">{roleMessage}</div> : null}
      </div>

      <div className="rounded-2xl border border-border bg-white p-6">
        <div className="text-sm font-semibold text-ink">Aksi akun</div>
        <div className="mt-4 flex flex-col gap-3 sm:flex-row">
          <Link to="/langganan">
            <Button variant="secondary">Kelola Paket</Button>
          </Link>
          <Link to="/bookmark">
            <Button variant="secondary">
              <Bookmark size={16} />
              Bookmark Saya
            </Button>
          </Link>
          <Link to="/wishlist">
            <Button variant="secondary">
              <Heart size={16} />
              Wishlist Saya
            </Button>
          </Link>
          <Link to="/penulis">
            <Button variant="secondary">
              <PenSquare size={16} />
              Portal Penulis
            </Button>
          </Link>
          <a href={`mailto:${user.email}`}>
            <Button variant="secondary">
              <Mail size={16} />
              Email Saya
            </Button>
          </a>
          <Button
            variant="danger"
            onClick={async () => {
              await logout();
              navigate("/login");
            }}
          >
            <LogOut size={16} />
            Keluar
          </Button>
        </div>
      </div>
    </div>
  );
}
