import { describe, expect, it } from "vitest";
import { resolveTrustedCheckoutPayload } from "./checkoutSecurity.js";

describe("resolveTrustedCheckoutPayload", () => {
  const authUser = {
    id: "user_123",
    email: "reader@example.com",
    user_metadata: {
      full_name: "Reader Naraloka",
    },
  };

  it("mengabaikan nominal membership palsu dari client dan memakai harga server", async () => {
    const result = await resolveTrustedCheckoutPayload({
      itemType: "MEMBERSHIP",
      membershipPlan: "PREMIUM",
      amount: 1000,
      buyerName: "Nama Client",
      buyerWhatsApp: "081234567890",
      authUser,
    });

    expect(result.userId).toBe("user_123");
    expect(result.amount).toBe(49000);
    expect(result.buyerEmail).toBe("reader@example.com");
    expect(result.platformCommissionPct).toBe(30);
    expect(result.authorRoyaltyCents).toBe(0);
  });

  it("mengabaikan nominal ebook palsu dari client dan memakai harga katalog server", async () => {
    const result = await resolveTrustedCheckoutPayload({
      itemType: "EBOOK",
      ebookId: "eb-lemari-kenangan",
      amount: 5000,
      buyerWhatsApp: "081234567890",
      authUser,
    });

    expect(result.itemType).toBe("EBOOK");
    expect(result.amount).toBe(39000);
    expect(result.ebookId).toBe("eb-lemari-kenangan");
    expect(result.platformCommissionPct).toBe(20);
    expect(result.authorRoyaltyCents).toBe(3120000);
  });

  it("menolak paket membership tidak valid", async () => {
    await expect(
      resolveTrustedCheckoutPayload({
        itemType: "MEMBERSHIP",
        membershipPlan: "VIP",
        buyerWhatsApp: "081234567890",
        authUser,
      })
    ).rejects.toThrow("Paket membership yang dipilih tidak valid.");
  });
});
