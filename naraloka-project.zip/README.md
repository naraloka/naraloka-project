# Naraloka (Book Platform) — Prototipe UI/UX

Prototipe platform e-book kerja sama penulis: Beranda, Katalog, Detail E-book, Reader (bookmark/highlight/catatan/offline simulasi), Portal Penulis, dan Dashboard Admin.

## Menjalankan Lokal

```bash
npm install
npm run dev
```

## Konfigurasi Midtrans

1. Salin file `.env.example` menjadi `.env`
2. Isi kredensial Midtrans:

```bash
VITE_MIDTRANS_ENV=sandbox
VITE_MIDTRANS_CLIENT_KEY=SB-Mid-client-xxxxxxxxxxxx
MIDTRANS_SERVER_KEY=SB-Mid-server-xxxxxxxxxxxx
```

3. Jalankan aplikasi:

```bash
npm install
npm run dev
```

Catatan:
- Checkout memanggil endpoint `/api/midtrans/token`
- Saat `npm run dev`, endpoint Midtrans juga aktif lewat middleware Vite
- Untuk deploy di Vercel, tambahkan env yang sama di Project Settings -> Environment Variables

## Konfigurasi Supabase Auth

1. Buat project di Supabase.
2. Buka **Project Settings -> API** lalu salin:
   - `Project URL`
   - `anon public key`
3. Tambahkan ke `.env`:

```bash
VITE_PUBLIC_APP_URL=https://your-public-domain.vercel.app
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
```

4. Di dashboard Supabase, aktifkan provider auth yang dibutuhkan:
   - `Email`
   - `Google`
5. Jika ingin tes lewat domain publik, isi `VITE_PUBLIC_APP_URL` dengan URL deploy kamu.
6. Di `Authentication -> URL Configuration`, isi:
   - `Site URL`: `https://domain-kamu`
   - `Redirect URLs`:
     - `https://domain-kamu/login`
     - `https://domain-kamu/`
     - opsional untuk lokal: `http://localhost:5175/login`
7. Untuk Google OAuth, callback di Google Cloud tetap:
   - `https://your-project-ref.supabase.co/auth/v1/callback`

Catatan:
- Login, daftar, logout, dan sesi akun sekarang memakai Supabase Auth.
- Metadata user menyimpan `full_name` dan `membership_plan`.
- Jika environment Supabase belum diisi, halaman login akan menampilkan pesan konfigurasi belum siap.
- Redirect login Google, email konfirmasi, dan finish URL checkout akan memakai `VITE_PUBLIC_APP_URL` jika diisi.

## Deploy Publik (Vercel)

1. Buat repository GitHub baru, lalu push project ini.
2. Buka Vercel → **New Project** → Import repo GitHub.
3. Pastikan pengaturan berikut:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Environment Variables:
     - `VITE_MIDTRANS_ENV`
     - `VITE_MIDTRANS_CLIENT_KEY`
     - `MIDTRANS_SERVER_KEY`
     - `VITE_PUBLIC_APP_URL`
     - `VITE_SUPABASE_URL`
     - `VITE_SUPABASE_ANON_KEY`
4. Klik **Deploy** → Vercel akan memberi URL publik.
5. Setelah URL publik keluar, set:
   - `VITE_PUBLIC_APP_URL=https://domain-vercel-kamu.vercel.app`
   - `Supabase -> Authentication -> URL Configuration -> Site URL = https://domain-vercel-kamu.vercel.app`
   - `Supabase -> Authentication -> URL Configuration -> Redirect URLs` tambahkan:
     - `https://domain-vercel-kamu.vercel.app/login`
     - `https://domain-vercel-kamu.vercel.app/`

Catatan:
- File [vercel.json](./vercel.json) sudah disiapkan agar routing React Router tetap berjalan saat refresh URL.

## Deploy Publik (Netlify)

1. Import repository ke Netlify
2. Build setting:
   - Build command: `npm run build`
   - Publish directory: `dist`
3. Tambahkan environment variables:
   - `VITE_MIDTRANS_ENV`
   - `VITE_MIDTRANS_CLIENT_KEY`
   - `MIDTRANS_SERVER_KEY`
   - `VITE_PUBLIC_APP_URL`
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Setelah URL publik keluar, set:
   - `VITE_PUBLIC_APP_URL=https://domain-netlify-kamu.netlify.app`
   - `Supabase -> Authentication -> URL Configuration -> Site URL = https://domain-netlify-kamu.netlify.app`
   - `Supabase -> Authentication -> URL Configuration -> Redirect URLs` tambahkan:
     - `https://domain-netlify-kamu.netlify.app/login`
     - `https://domain-netlify-kamu.netlify.app/`

Catatan:
- File [netlify.toml](./netlify.toml) sudah menyiapkan:
  - redirect SPA `/* -> /index.html`
  - redirect endpoint `/api/midtrans/token` ke Netlify Function
