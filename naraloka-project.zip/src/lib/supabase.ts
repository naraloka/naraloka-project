import { createClient } from "@supabase/supabase-js";
import type { User } from "@supabase/supabase-js";
import type { MembershipPlan, UserProfile } from "@/types/domain";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl!, supabaseAnonKey!, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;

function parseMembershipPlan(value: unknown): MembershipPlan {
  if (value === "PREMIUM" || value === "EDU") return value;
  return "FREE";
}

export function getSupabaseUserProfile(user: User): UserProfile {
  const fullName =
    typeof user.user_metadata?.full_name === "string" && user.user_metadata.full_name.trim()
      ? user.user_metadata.full_name.trim()
      : user.email?.split("@")[0] || "Pengguna";

  return {
    id: user.id,
    name: fullName,
    email: user.email ?? "",
    role: "READER",
    membershipPlan: parseMembershipPlan(user.user_metadata?.membership_plan),
  };
}

export function getReadableSupabaseError(message: string) {
  if (!message) return "Terjadi kesalahan autentikasi.";
  if (message.toLowerCase().includes("invalid login credentials")) {
    return "Email atau password salah.";
  }
  if (message.toLowerCase().includes("email not confirmed")) {
    return "Email belum dikonfirmasi. Cek inbox email kamu.";
  }
  if (message.toLowerCase().includes("user already registered")) {
    return "Email sudah terdaftar. Silakan masuk.";
  }
  return message;
}
