import { create } from "zustand";
import type { MembershipPlan, UserProfile, UserRole } from "@/types/domain";
import { getAppUrl } from "@/lib/appUrl";
import { getReadableSupabaseError, getSupabaseUserProfile, isSupabaseConfigured, supabase } from "@/lib/supabase";

type SessionState = {
  user: UserProfile | null;
  authReady: boolean;
  authError: string;
  initializeAuth: () => Promise<void>;
  signInWithPassword: (input: { email: string; password: string }) => Promise<{ error: string }>;
  signUpWithPassword: (input: { name: string; email: string; password: string }) => Promise<{
    error: string;
    requiresEmailConfirmation: boolean;
  }>;
  signInWithGoogle: () => Promise<{ error: string }>;
  logout: () => Promise<void>;
  setMembershipPlan: (plan: MembershipPlan) => Promise<{ error: string }>;
};

let authInitialized = false;

export const useSessionStore = create<SessionState>()((set, get) => ({
  user: null,
  authReady: false,
  authError: "",

  initializeAuth: async () => {
    if (!isSupabaseConfigured || !supabase) {
      set({
        user: null,
        authReady: true,
        authError: "Konfigurasi Supabase belum diisi. Tambahkan VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY.",
      });
      return;
    }

    if (!authInitialized) {
      authInitialized = true;
      supabase.auth.onAuthStateChange((_event, session) => {
        set({
          user: session?.user ? getSupabaseUserProfile(session.user) : null,
          authReady: true,
          authError: "",
        });
      });
    }

    const { data, error } = await supabase.auth.getSession();
    set({
      user: data.session?.user ? getSupabaseUserProfile(data.session.user) : null,
      authReady: true,
      authError: error ? getReadableSupabaseError(error.message) : "",
    });
  },

  signInWithPassword: async ({ email, password }) => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi." };
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    return { error: error ? getReadableSupabaseError(error.message) : "" };
  },

  signUpWithPassword: async ({ name, email, password }) => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi.", requiresEmailConfirmation: false };
    }

    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        emailRedirectTo: getAppUrl("/login"),
        data: {
          full_name: name.trim(),
          role: "READER" satisfies UserRole,
          membership_plan: "FREE" satisfies MembershipPlan,
        },
      },
    });

    return {
      error: error ? getReadableSupabaseError(error.message) : "",
      requiresEmailConfirmation: !error && !data.session,
    };
  },

  signInWithGoogle: async () => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi." };
    }

    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: getAppUrl("/login"),
        queryParams: {
          prompt: "select_account",
        },
      },
    });

    return { error: error ? getReadableSupabaseError(error.message) : "" };
  },

  logout: async () => {
    if (!supabase) {
      set({ user: null });
      return;
    }

    await supabase.auth.signOut();
    set({ user: null });
  },

  setMembershipPlan: async (plan) => {
    if (!supabase) {
      return { error: "Supabase belum dikonfigurasi." };
    }

    const currentUser = supabase.auth.getUser
      ? (await supabase.auth.getUser()).data.user
      : null;

    if (!currentUser) {
      return { error: "Kamu harus login dulu." };
    }

    const { error } = await supabase.auth.updateUser({
      data: {
        ...currentUser.user_metadata,
        membership_plan: plan,
      },
    });

    if (!error) {
      set((state) => ({
        user: state.user ? { ...state.user, membershipPlan: plan } : state.user,
      }));
    }

    return { error: error ? getReadableSupabaseError(error.message) : "" };
  },
}));
