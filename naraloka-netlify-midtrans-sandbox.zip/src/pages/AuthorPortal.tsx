import { useMemo, useState } from "react";
import { BarChart3, FileUp, Handshake, Mail, Phone } from "lucide-react";
import Badge from "@/components/Badge";
import Button from "@/components/Button";
import Input from "@/components/Input";
import { supportEmailUrl, supportWhatsAppUrl } from "@/constants/contact";
import { authors, ebooks } from "@/data/mock";
import { cn } from "@/lib/utils";
import { usePublishingStore } from "@/stores/publishingStore";
import { useSessionStore } from "@/stores/sessionStore";
import type { BookCategory } from "@/types/domain";
import { formatIdrFromCents } from "@/utils/format";

type TabKey = "kerjasama" | "upload" | "dashboard";

export default function AuthorPortal() {
  const user = useSessionStore((s) => s.user);
  const role = user?.role ?? "READER";

  const [tab, setTab] = useState<TabKey>("dashboard");
  const [proposalSent, setProposalSent] = useState(false);

  const manuscripts = usePublishingStore((s) => s.manuscripts);
  const submitManuscript = usePublishingStore((s) => s.submitManuscript);
  const royalty = usePublishingStore((s) => s.royalty);

  const authorId = "a-nara";
  const author = authors.find((a) => a.id === authorId);
  const myBooks = ebooks.filter((b) => b.authorId === authorId);
  const myManuscripts = manuscripts.filter((m) => m.authorId === authorId);

  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadCategory, setUploadCategory] = useState<BookCategory>("Novel");
  const [uploadFileName, setUploadFileName] = useState("");

  const fakeSales = useMemo(() => {
    const base = myBooks.map((b, idx) => {
      const sold = Math.max(120, Math.round(b.ratingCount / (idx + 2)));
      const gross = sold * b.priceCents;
      const authorShare = Math.round((gross * royalty.authorRoyaltyPct) / 100);
      return {
        ebookId: b.id,
        title: b.title,
        sold,
        gross,
        authorShare,
      };
    });
    return base;
  }, [myBooks, royalty.authorRoyaltyPct]);

  const maxSold = useMemo(() => {
    return fakeSales.reduce((acc, s) => Math.max(acc, s.sold), 1);
  }, [fakeSales]);

  const totals = useMemo(() => {
    const gross = fakeSales.reduce((acc, s) => acc + s.gross, 0);
    const authorShare = fakeSales.reduce((acc, s) => acc + s.authorShare, 0);
    const sold = fakeSales.reduce((acc, s) => acc + s.sold, 0);
    return { gross, authorShare, sold };
  }, [fakeSales]);

  if (role !== "AUTHOR") {
    return (
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-10">
        <div className="text-2xl font-semibold tracking-tight text-ink">Portal Penulis</div>
        <div className="mt-2 text-sm text-muted">
          Halaman ini ditujukan untuk penulis. Ubah Mode menjadi Penulis di header untuk melihat fitur kerja sama.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="text-2xl font-semibold tracking-tight text-ink md:text-4xl">
              Portal Penulis
            </div>
            <div className="mt-2 text-sm text-muted">
              Ajukan kerja sama, upload naskah, dan pantau performa penjualan & royalti.
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge tone="brand">Bagi hasil {royalty.authorRoyaltyPct}%</Badge>
              <Badge tone="neutral">Komisi platform {royalty.platformCommissionPct}%</Badge>
              <Badge tone="neutral">Status transparan</Badge>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-2xl border border-border bg-surface p-4">
            <div className="h-12 w-12 overflow-hidden rounded-2xl bg-white">
              {author?.avatarUrl ? (
                <img src={author.avatarUrl} alt={author.displayName} className="h-full w-full object-cover" />
              ) : null}
            </div>
            <div>
              <div className="text-sm font-semibold text-ink">{author?.displayName ?? "Penulis"}</div>
              <div className="mt-1 text-xs text-muted">{author?.bio ?? ""}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setTab("dashboard")}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition",
            tab === "dashboard"
              ? "border-brand-2 bg-brand-2/10 text-brand-2"
              : "border-border bg-white text-muted hover:bg-surface"
          )}
        >
          <BarChart3 size={16} />
          Dashboard
        </button>
        <button
          type="button"
          onClick={() => setTab("kerjasama")}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition",
            tab === "kerjasama"
              ? "border-brand-2 bg-brand-2/10 text-brand-2"
              : "border-border bg-white text-muted hover:bg-surface"
          )}
        >
          <Handshake size={16} />
          Kerja Sama
        </button>
        <button
          type="button"
          onClick={() => setTab("upload")}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition",
            tab === "upload"
              ? "border-brand-2 bg-brand-2/10 text-brand-2"
              : "border-border bg-white text-muted hover:bg-surface"
          )}
        >
          <FileUp size={16} />
          Upload Naskah
        </button>
      </div>

      {tab === "dashboard" ? (
        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl border border-border bg-white p-5">
            <div className="text-xs font-semibold text-muted">Total penjualan (simulasi)</div>
            <div className="mt-2 text-2xl font-semibold tracking-tight text-ink">
              {totals.sold.toLocaleString("id-ID")}
            </div>
            <div className="mt-1 text-sm text-muted">unit</div>
          </div>
          <div className="rounded-2xl border border-border bg-white p-5">
            <div className="text-xs font-semibold text-muted">Gross revenue (simulasi)</div>
            <div className="mt-2 text-2xl font-semibold tracking-tight text-ink">
              {formatIdrFromCents(totals.gross)}
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-white p-5">
            <div className="text-xs font-semibold text-muted">Estimasi royalti</div>
            <div className="mt-2 text-2xl font-semibold tracking-tight text-ink">
              {formatIdrFromCents(totals.authorShare)}
            </div>
            <div className="mt-1 text-sm text-muted">sebelum payout</div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 md:col-span-2">
            <div className="text-sm font-semibold text-ink">Performa buku</div>
            <div className="mt-4 space-y-4">
              {fakeSales.length ? (
                fakeSales.map((s) => {
                  const pct = Math.round((s.sold / maxSold) * 100);
                  return (
                    <div key={s.ebookId} className="grid gap-2">
                      <div className="flex items-center justify-between gap-3">
                        <div className="text-sm font-semibold text-ink">{s.title}</div>
                        <div className="text-xs text-muted">
                          {s.sold.toLocaleString("id-ID")} unit • {formatIdrFromCents(s.authorShare)} royalti
                        </div>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-surface">
                        <div className="h-full bg-brand-2" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-sm text-muted">Belum ada e-book yang tersedia.</div>
              )}
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6">
            <div className="text-sm font-semibold text-ink">Riwayat transaksi</div>
            <div className="mt-2 text-sm text-muted">Simulasi ringkas (3 terbaru).</div>
            <div className="mt-4 space-y-3">
              {fakeSales.length ? (
                fakeSales.slice(0, 3).map((s) => (
                  <div key={s.ebookId} className="rounded-2xl border border-border bg-surface p-4">
                    <div className="text-xs font-semibold text-muted">Royalti masuk</div>
                    <div className="mt-1 text-sm font-semibold text-ink">{formatIdrFromCents(s.authorShare)}</div>
                    <div className="mt-1 text-xs text-muted">{s.title}</div>
                  </div>
                ))
              ) : (
                <div className="text-sm text-muted">Belum ada transaksi.</div>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {tab === "kerjasama" ? (
        <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
          <div className="text-sm font-semibold text-ink">Form pengajuan kerja sama</div>
          <div className="mt-2 text-sm text-muted">
            Isi data ringkas. Tim Naraloka akan menghubungi via email/WhatsApp (simulasi).
          </div>

          {proposalSent ? (
            <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
              Pengajuan terkirim. Kami akan menghubungi kamu dalam 1–2 hari kerja.
            </div>
          ) : null}

          <div className="mt-5 grid gap-3 md:grid-cols-2">
            <Input placeholder="Nama penulis" defaultValue={author?.displayName ?? ""} />
            <Input placeholder="Email" defaultValue={user?.email ?? ""} />
            <Input placeholder="Nomor WhatsApp" />
            <Input placeholder="Link portofolio (opsional)" />
            <textarea
              className="md:col-span-2 min-h-28 w-full resize-none rounded-2xl border border-border bg-white p-3 text-sm text-ink outline-none transition focus:border-brand-2 focus:ring-2 focus:ring-brand-2/15"
              placeholder="Ceritakan karya dan target pembaca…"
            />
          </div>

          <div className="mt-5 flex flex-col gap-2 sm:flex-row">
            <Button onClick={() => setProposalSent(true)}>
              <Handshake size={16} />
              Kirim Pengajuan
            </Button>
            <a href={supportWhatsAppUrl} className="sm:w-auto">
              <Button variant="secondary" className="w-full sm:w-auto">
                <Phone size={16} />
                WhatsApp CS
              </Button>
            </a>
            <a href={supportEmailUrl} className="sm:w-auto">
              <Button variant="secondary" className="w-full sm:w-auto">
                <Mail size={16} />
                Email
              </Button>
            </a>
          </div>
        </div>
      ) : null}

      {tab === "upload" ? (
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="text-sm font-semibold text-ink">Upload naskah</div>
            <div className="mt-2 text-sm text-muted">
              Unggah file naskah dan metadata. Status akan muncul di daftar pengajuan.
            </div>

            <div className="mt-5 grid gap-3">
              <Input value={uploadTitle} onChange={(e) => setUploadTitle(e.target.value)} placeholder="Judul naskah" />
              <select
                value={uploadCategory}
                onChange={(e) => setUploadCategory(e.target.value as BookCategory)}
                className="h-10 w-full rounded-xl border border-border bg-white px-3 text-sm font-semibold text-ink outline-none"
              >
                <option value="Novel">Novel</option>
                <option value="Edukasi">Edukasi</option>
                <option value="Motivasi">Motivasi</option>
                <option value="Cerpen">Cerpen</option>
                <option value="Komik Digital">Komik Digital</option>
              </select>
              <input
                type="file"
                className="block w-full text-sm text-muted file:mr-3 file:rounded-xl file:border file:border-border file:bg-white file:px-4 file:py-2 file:text-sm file:font-semibold file:text-ink hover:file:bg-surface"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  setUploadFileName(f?.name ?? "");
                }}
              />
              <Button
                onClick={() => {
                  const title = uploadTitle.trim();
                  const fileName = uploadFileName.trim();
                  if (!title || !fileName) return;
                  submitManuscript({
                    authorId,
                    title,
                    category: uploadCategory,
                    fileName,
                  });
                  setUploadTitle("");
                  setUploadFileName("");
                }}
              >
                <FileUp size={16} />
                Kirim untuk Review
              </Button>
              <div className="text-xs text-muted">
                Format file: DOCX/PDF (simulasi). Validasi akan ditambahkan di fase backend.
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="text-sm font-semibold text-ink">Status pengajuan</div>
            <div className="mt-4 space-y-3">
              {myManuscripts.length ? (
                myManuscripts.map((m) => (
                  <div key={m.id} className="rounded-2xl border border-border bg-surface p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold text-ink">{m.title}</div>
                        <div className="mt-1 text-xs text-muted">
                          {m.category} • {m.fileName}
                        </div>
                      </div>
                      <Badge
                        tone={
                          m.status === "APPROVED"
                            ? "success"
                            : m.status === "REJECTED"
                              ? "warning"
                              : "neutral"
                        }
                      >
                        {m.status}
                      </Badge>
                    </div>
                    {m.adminNote ? (
                      <div className="mt-3 text-sm text-muted">{m.adminNote}</div>
                    ) : null}
                  </div>
                ))
              ) : (
                <div className="text-sm text-muted">Belum ada pengajuan.</div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
