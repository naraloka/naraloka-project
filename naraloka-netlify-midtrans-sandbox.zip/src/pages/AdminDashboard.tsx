import { useMemo, useState } from "react";
import {
  BadgeCheck,
  BookCopy,
  FileCheck2,
  LineChart,
  Settings,
  Users,
} from "lucide-react";
import Badge from "@/components/Badge";
import Button from "@/components/Button";
import Input from "@/components/Input";
import { authors, ebooks } from "@/data/mock";
import { cn } from "@/lib/utils";
import { usePublishingStore } from "@/stores/publishingStore";
import { useSessionStore } from "@/stores/sessionStore";
import { formatIdrFromCents } from "@/utils/format";

type TabKey =
  | "submissions"
  | "catalog"
  | "authors"
  | "users"
  | "reports"
  | "settings";

export default function AdminDashboard() {
  const user = useSessionStore((s) => s.user);
  const role = user?.role ?? "READER";
  const [tab, setTab] = useState<TabKey>("submissions");

  const manuscripts = usePublishingStore((s) => s.manuscripts);
  const approve = usePublishingStore((s) => s.approve);
  const reject = usePublishingStore((s) => s.reject);
  const royalty = usePublishingStore((s) => s.royalty);
  const setCommissionPct = usePublishingStore((s) => s.setCommissionPct);

  const pending = manuscripts.filter((m) => m.status === "SUBMITTED");

  const kpis = useMemo(() => {
    const totalBooks = ebooks.length;
    const totalAuthors = authors.length;
    const totalTransactions = Math.max(1520, ebooks.reduce((acc, b) => acc + Math.round(b.ratingCount / 3), 0));
    const revenue = ebooks.reduce((acc, b) => acc + b.priceCents * Math.round(b.ratingCount / 4), 0);
    return { totalBooks, totalAuthors, totalTransactions, revenue };
  }, []);

  if (role !== "ADMIN") {
    return (
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-10">
        <div className="text-2xl font-semibold tracking-tight text-ink">Dashboard Admin</div>
        <div className="mt-2 text-sm text-muted">
          Halaman ini ditujukan untuk admin. Ubah Mode menjadi Admin di header untuk melihat fitur pengelolaan.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-10">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="text-2xl font-semibold tracking-tight text-ink md:text-4xl">
              Dashboard Admin
            </div>
            <div className="mt-2 text-sm text-muted">
              Manajemen pengguna, penulis, katalog, persetujuan naskah, dan monitoring transaksi (simulasi).
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge tone="brand">Komisi {royalty.platformCommissionPct}%</Badge>
              <Badge tone="neutral">Royalti penulis {royalty.authorRoyaltyPct}%</Badge>
              {pending.length ? <Badge tone="warning">{pending.length} naskah menunggu</Badge> : <Badge tone="success">Semua aman</Badge>}
            </div>
          </div>
          <div className="grid w-full gap-3 md:max-w-md md:grid-cols-2">
            <div className="rounded-2xl border border-border bg-surface p-4">
              <div className="text-xs font-semibold text-muted">Transaksi</div>
              <div className="mt-2 text-xl font-semibold text-ink">
                {kpis.totalTransactions.toLocaleString("id-ID")}
              </div>
            </div>
            <div className="rounded-2xl border border-border bg-surface p-4">
              <div className="text-xs font-semibold text-muted">Pendapatan (simulasi)</div>
              <div className="mt-2 text-xl font-semibold text-ink">{formatIdrFromCents(kpis.revenue)}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <TabButton active={tab === "submissions"} onClick={() => setTab("submissions")} icon={FileCheck2}>
          Persetujuan naskah
        </TabButton>
        <TabButton active={tab === "catalog"} onClick={() => setTab("catalog")} icon={BookCopy}>
          Katalog
        </TabButton>
        <TabButton active={tab === "authors"} onClick={() => setTab("authors")} icon={BadgeCheck}>
          Penulis
        </TabButton>
        <TabButton active={tab === "users"} onClick={() => setTab("users")} icon={Users}>
          Pengguna
        </TabButton>
        <TabButton active={tab === "reports"} onClick={() => setTab("reports")} icon={LineChart}>
          Laporan
        </TabButton>
        <TabButton active={tab === "settings"} onClick={() => setTab("settings")} icon={Settings}>
          Komisi & royalti
        </TabButton>
      </div>

      {tab === "submissions" ? (
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-border bg-white p-6">
            <div className="text-sm font-semibold text-ink">Menunggu review</div>
            <div className="mt-4 space-y-3">
              {pending.length ? (
                pending.map((m) => <ManuscriptCard key={m.id} id={m.id} title={m.title} category={m.category} fileName={m.fileName} authorId={m.authorId} onApprove={() => approve(m.id)} onReject={(note) => reject(m.id, note)} />)
              ) : (
                <div className="text-sm text-muted">Tidak ada naskah yang menunggu.</div>
              )}
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-white p-6">
            <div className="text-sm font-semibold text-ink">Riwayat keputusan</div>
            <div className="mt-4 space-y-3">
              {manuscripts
                .filter((m) => m.status !== "SUBMITTED")
                .slice(0, 6)
                .map((m) => (
                  <div key={m.id} className="rounded-2xl border border-border bg-surface p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold text-ink">{m.title}</div>
                        <div className="mt-1 text-xs text-muted">{m.category}</div>
                      </div>
                      <Badge tone={m.status === "APPROVED" ? "success" : "warning"}>{m.status}</Badge>
                    </div>
                    {m.adminNote ? <div className="mt-3 text-sm text-muted">{m.adminNote}</div> : null}
                  </div>
                ))}
            </div>
          </div>
        </div>
      ) : null}

      {tab === "catalog" ? (
        <div className="rounded-2xl border border-border bg-white p-6">
          <div className="text-sm font-semibold text-ink">Manajemen katalog (simulasi)</div>
          <div className="mt-2 text-sm text-muted">CRUD dan label akses akan diintegrasikan pada fase backend.</div>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {ebooks.map((b) => (
              <div key={b.id} className="flex gap-4 rounded-2xl border border-border bg-surface p-4">
                <div className="h-20 w-16 overflow-hidden rounded-xl bg-white">
                  <img src={b.coverUrl} alt={b.title} className="h-full w-full object-cover" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold text-ink">{b.title}</div>
                  <div className="mt-1 text-xs text-muted">
                    {b.category} • {b.access}
                    {b.requiredPlan ? ` • ${b.requiredPlan}` : ""}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {b.isFeatured ? <Badge tone="brand">Unggulan</Badge> : null}
                    {b.isBestSeller ? <Badge tone="warning">Best Seller</Badge> : null}
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Button size="sm" variant="secondary">
                    Edit
                  </Button>
                  <Button size="sm" variant="secondary">
                    Atur akses
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {tab === "authors" ? (
        <div className="rounded-2xl border border-border bg-white p-6">
          <div className="text-sm font-semibold text-ink">Manajemen penulis</div>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {authors.map((a) => (
              <div key={a.id} className="flex items-center gap-4 rounded-2xl border border-border bg-surface p-4">
                <div className="h-12 w-12 overflow-hidden rounded-2xl bg-white">
                  {a.avatarUrl ? <img src={a.avatarUrl} alt={a.displayName} className="h-full w-full object-cover" /> : null}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold text-ink">{a.displayName}</div>
                  <div className="mt-1 line-clamp-1 text-xs text-muted">{a.bio}</div>
                </div>
                <Button size="sm" variant="secondary">
                  Detail
                </Button>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {tab === "users" ? (
        <div className="rounded-2xl border border-border bg-white p-6">
          <div className="text-sm font-semibold text-ink">Manajemen pengguna (simulasi)</div>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {["Alya", "Dimas", "Nita", "Rafi", "Sari", "Bagas"].map((name) => (
              <div key={name} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-surface p-4">
                <div>
                  <div className="text-sm font-semibold text-ink">{name}</div>
                  <div className="mt-1 text-xs text-muted">Status: aktif</div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="secondary">
                    Reset
                  </Button>
                  <Button size="sm" variant="secondary">
                    Suspend
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {tab === "reports" ? (
        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl border border-border bg-white p-6 md:col-span-2">
            <div className="text-sm font-semibold text-ink">Analisis performa (simulasi)</div>
            <div className="mt-2 text-sm text-muted">Contoh chart sederhana tanpa dependensi tambahan.</div>
            <div className="mt-5 grid gap-4">
              {ebooks.slice(0, 5).map((b) => {
                const score = Math.round((b.ratingAvg / 5) * 100);
                return (
                  <div key={b.id} className="grid gap-2">
                    <div className="flex items-center justify-between gap-3">
                      <div className="text-sm font-semibold text-ink">{b.title}</div>
                      <div className="text-xs text-muted">Skor {score}/100</div>
                    </div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-surface">
                      <div className="h-full bg-brand-2" style={{ width: `${score}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-white p-6">
            <div className="text-sm font-semibold text-ink">Laporan penjualan</div>
            <div className="mt-2 text-sm text-muted">Export & filter periode (rencana).</div>
            <div className="mt-5 space-y-3">
              <div className="rounded-2xl border border-border bg-surface p-4">
                <div className="text-xs font-semibold text-muted">Total buku</div>
                <div className="mt-1 text-lg font-semibold text-ink">{kpis.totalBooks}</div>
              </div>
              <div className="rounded-2xl border border-border bg-surface p-4">
                <div className="text-xs font-semibold text-muted">Total penulis</div>
                <div className="mt-1 text-lg font-semibold text-ink">{kpis.totalAuthors}</div>
              </div>
              <Button variant="secondary" className="w-full">
                Export CSV
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {tab === "settings" ? (
        <div className="rounded-2xl border border-border bg-white p-6">
          <div className="text-sm font-semibold text-ink">Pengaturan komisi & royalti</div>
          <div className="mt-2 text-sm text-muted">
            Atur komisi platform. Royalti penulis mengikuti 100% - komisi.
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-border bg-surface p-5">
              <div className="text-xs font-semibold text-muted">Komisi platform</div>
              <div className="mt-2 text-2xl font-semibold tracking-tight text-ink">
                {royalty.platformCommissionPct}%
              </div>
              <input
                type="range"
                min={0}
                max={60}
                value={royalty.platformCommissionPct}
                onChange={(e) => setCommissionPct(Number(e.target.value))}
                className="mt-4 w-full"
              />
              <div className="mt-2 text-xs text-muted">Batas maksimal 60% untuk demo.</div>
            </div>

            <div className="rounded-2xl border border-border bg-surface p-5">
              <div className="text-xs font-semibold text-muted">Royalti penulis</div>
              <div className="mt-2 text-2xl font-semibold tracking-tight text-ink">
                {royalty.authorRoyaltyPct}%
              </div>
              <div className="mt-2 text-sm text-muted">
                Skema bagi hasil transparan dan dapat disesuaikan per kontrak (rencana).
              </div>
              <div className="mt-4 grid gap-2">
                <Input placeholder="Rule khusus (opsional)" />
                <Button variant="secondary">Simpan</Button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon: Icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof Users;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition",
        active
          ? "border-brand-2 bg-brand-2/10 text-brand-2"
          : "border-border bg-white text-muted hover:bg-surface"
      )}
    >
      <Icon size={16} />
      {children}
    </button>
  );
}

function ManuscriptCard({
  id,
  title,
  category,
  fileName,
  authorId,
  onApprove,
  onReject,
}: {
  id: string;
  title: string;
  category: string;
  fileName: string;
  authorId: string;
  onApprove: () => void;
  onReject: (note: string) => void;
}) {
  const author = authors.find((a) => a.id === authorId);
  const [note, setNote] = useState("");

  return (
    <div className="rounded-2xl border border-border bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold text-ink">{title}</div>
          <div className="mt-1 text-xs text-muted">
            {category} • {fileName}
          </div>
          <div className="mt-1 text-xs text-muted">Penulis: {author?.displayName ?? authorId}</div>
        </div>
        <Badge tone="warning">SUBMITTED</Badge>
      </div>

      <div className="mt-4 grid gap-2">
        <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Catatan admin (opsional)" />
        <div className="grid grid-cols-2 gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => {
              onApprove();
              setNote("");
            }}
          >
            Approve
          </Button>
          <Button
            size="sm"
            variant="danger"
            onClick={() => {
              onReject(note.trim() || "Mohon revisi dan kirim ulang dengan perbaikan struktur.");
              setNote("");
            }}
          >
            Reject
          </Button>
        </div>
      </div>
    </div>
  );
}

