import { Chrome } from "lucide-react";
import Button from "@/components/Button";
import Input from "@/components/Input";
import { useSessionStore } from "@/stores/sessionStore";

export default function Login() {
  const loginDemo = useSessionStore((s) => s.loginDemo);

  return (
    <div className="mx-auto max-w-md">
      <div className="rounded-[2rem] border border-border bg-white p-6 shadow-soft md:p-8">
        <div className="text-2xl font-semibold tracking-tight text-ink">Masuk</div>
        <div className="mt-2 text-sm text-muted">
          Ini prototipe UI/UX. Login Google akan diintegrasikan via OAuth pada fase backend.
        </div>

        <div className="mt-6 grid gap-3">
          <Input placeholder="Email" type="email" />
          <Input placeholder="Password" type="password" />
          <Button variant="secondary" onClick={() => loginDemo("READER")}>
            Masuk (Demo)
          </Button>
          <Button variant="secondary" onClick={() => loginDemo("AUTHOR")}>
            Masuk sebagai Penulis (Demo)
          </Button>
          <Button variant="secondary" onClick={() => loginDemo("ADMIN")}>
            Masuk sebagai Admin (Demo)
          </Button>
        </div>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-border" />
          <div className="text-xs text-muted">atau</div>
          <div className="h-px flex-1 bg-border" />
        </div>

        <Button
          onClick={() => loginDemo("READER")}
          className="w-full"
          variant="secondary"
        >
          <Chrome size={16} />
          Masuk dengan Google
        </Button>
      </div>
    </div>
  );
}

