import { useMemo } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Bookmark, BookOpenText, Heart, ShoppingBag } from "lucide-react";
import Badge from "@/components/Badge";
import BookCard from "@/components/BookCard";
import Button from "@/components/Button";
import { ebooks } from "@/data/mock";
import { cn } from "@/lib/utils";
import { useLibraryStore } from "@/stores/libraryStore";
import { useSessionStore } from "@/stores/sessionStore";
import { formatIdrFromCents } from "@/utils/format";

function hasAccess(params: {
  owned: boolean;
  membershipPlan: "FREE" | "PREMIUM" | "EDU";
  access: "OPEN" | "MEMBERSHIP" | "PAID";
  requiredPlan?: "FREE" | "PREMIUM" | "EDU";
}) {
  const { owned, membershipPlan, access, requiredPlan } = params;
  if (access === "OPEN") return true;
  if (access === "PAID") return owned;
  if (access === "MEMBERSHIP") {
    if (!requiredPlan) return membershipPlan !== "FREE";
    return membershipPlan === requiredPlan || membershipPlan === "PREMIUM";
  }
  return false;
}

export default function EbookDetail() {
  const { ebookId } = useParams();
  const navigate = useNavigate();

  const user = useSessionStore((s) => s.user);
  const membershipPlan = user?.membershipPlan ?? "FREE";
  const uid = user?.id ?? "guest";

  const markOwned = useLibraryStore((s) => s.markOwned);
  const addToLibrary = useLibraryStore((s) => s.addToLibrary);
  const toggleWishlist = useLibraryStore((s) => s.toggleWishlist);
  const library = useLibraryStore((s) => s.libraryByUser);
  const wishlist = useLibraryStore((s) => s.wishlistByUser);

  const ebook = ebooks.find((b) => b.id === ebookId);
  const owned = Boolean(library[uid]?.[ebook?.id ?? ""]?.owned);
  const allowed = ebook
    ? hasAccess({
        owned,
        membershipPlan,
        access: ebook.access,
        requiredPlan: ebook.requiredPlan,
      })
    : false;

  const isWishlisted = ebook ? Boolean(wishlist[uid]?.[ebook.id]) : false;

  const similar = useMemo(() => {
    if (!ebook) return [];
    return ebooks
      .filter((b) => b.id !== ebook.id && (b.category === ebook.category || b.authorId === ebook.authorId))
      .slice(0, 6);
  }, [ebook]);

  if (!ebook) {
    return (
      <div className="rounded-2xl border border-border bg-white p-6 text-center">
        <div className="text-sm font-semibold text-ink">E-book tidak ditemukan</div>
        <div className="mt-1 text-sm text-muted">Coba kembali ke katalog.</div>
        <div className="mt-4">
          <Link to="/katalog">
            <Button variant="secondary">Kembali</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <div className="grid gap-8 lg:grid-cols-[360px_1fr]">
        <div className="space-y-4">
          <div className="overflow-hidden rounded-2xl border border-border bg-white shadow-soft">
            <img src={ebook.coverUrl} alt={ebook.title} className="w-full object-cover" />
          </div>

          <div className="rounded-2xl border border-border bg-white p-4">
            <div className="flex flex-wrap gap-2">
              {ebook.isBestSeller ? <Badge tone="warning">Best Seller</Badge> : null}
              {ebook.isFeatured ? <Badge tone="brand">Unggulan</Badge> : null}
              {ebook.access === "OPEN" ? <Badge tone="neutral">Gratis</Badge> : null}
              {ebook.access === "MEMBERSHIP" ? (
                <Badge tone="success">
                  Membership{ebook.requiredPlan ? ` • ${ebook.requiredPlan}` : ""}
                </Badge>
              ) : null}
              {ebook.access === "PAID" ? <Badge tone="neutral">Beli satuan</Badge> : null}
            </div>

            <div className="mt-4 flex items-center justify-between gap-3">
              <div className="text-sm font-semibold text-ink">Akses</div>
              <div className={cn("text-sm font-semibold", allowed ? "text-emerald-700" : "text-muted")}>
                {allowed ? "Tersedia" : "Perlu akses"}
              </div>
            </div>

            <div className="mt-4 grid gap-2">
              {ebook.access === "PAID" ? (
                <Button
                  onClick={() => {
                    markOwned(ebook.id, ebook.pageCount);
                    navigate("/checkout");
                  }}
                >
                  <ShoppingBag size={16} />
                  Beli Sekarang • {formatIdrFromCents(ebook.priceCents)}
                </Button>
              ) : null}

              <Button
                variant={allowed ? "primary" : "secondary"}
                onClick={() => {
                  addToLibrary(ebook.id, ebook.pageCount);
                  if (allowed) navigate(`/baca/${ebook.id}`);
                  else navigate("/langganan");
                }}
              >
                <BookOpenText size={16} />
                {allowed ? "Baca Sekarang" : "Tambah ke Perpustakaan"}
              </Button>

              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="secondary"
                  onClick={() => toggleWishlist(ebook.id)}
                  className={cn(isWishlisted && "border-brand-2 bg-brand-2/10 text-brand-2")}
                >
                  <Heart size={16} className={cn(isWishlisted && "fill-current")} />
                  Wishlist
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    addToLibrary(ebook.id, ebook.pageCount);
                    navigate("/perpustakaan");
                  }}
                >
                  <Bookmark size={16} />
                  Perpustakaan
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="text-2xl font-semibold tracking-tight text-ink md:text-3xl">
                  {ebook.title}
                </div>
                <div className="mt-2 text-sm text-muted">
                  {ebook.category} • {ebook.pageCount} halaman
                </div>
              </div>
              {ebook.tags.length ? (
                <div className="flex flex-wrap gap-2">
                  {ebook.tags.slice(0, 3).map((t) => (
                    <Badge key={t} tone="neutral">
                      {t}
                    </Badge>
                  ))}
                </div>
              ) : null}
            </div>

            <div className="mt-5 text-sm leading-relaxed text-muted">{ebook.description}</div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="flex items-end justify-between gap-4">
              <div>
                <div className="text-sm font-semibold text-ink">Preview beberapa halaman</div>
                <div className="mt-1 text-sm text-muted">
                  {allowed ? "Kamu bisa lanjut membaca di Reader." : "Preview terbatas. Upgrade untuk akses penuh."}
                </div>
              </div>
              <Link to={`/baca/${ebook.id}`}>
                <Button variant={allowed ? "primary" : "secondary"} size="sm">
                  {allowed ? "Buka Reader" : "Coba Preview"}
                </Button>
              </Link>
            </div>

            <div className="mt-5 grid gap-3">
              {ebook.previewPages.slice(0, 3).map((p, idx) => (
                <div key={idx} className="rounded-2xl border border-border bg-surface p-4">
                  <div className="text-xs font-semibold text-muted">Halaman {idx + 1}</div>
                  <div className="mt-2 whitespace-pre-wrap font-serif text-sm leading-relaxed text-ink">
                    {p}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-5">
            <div className="flex items-end justify-between gap-4">
              <div>
                <div className="text-lg font-semibold tracking-tight text-ink">Rekomendasi serupa</div>
                <div className="mt-1 text-sm text-muted">
                  Berdasarkan kategori dan tema bacaan yang mirip.
                </div>
              </div>
              <Link to="/katalog" className="text-sm font-semibold text-brand hover:underline">
                Kembali ke katalog
              </Link>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {similar.map((b) => (
                <BookCard key={b.id} ebook={b} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
