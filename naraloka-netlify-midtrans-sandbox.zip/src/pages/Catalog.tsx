import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Filter, Search } from "lucide-react";
import BookCard from "@/components/BookCard";
import Button from "@/components/Button";
import Input from "@/components/Input";
import Badge from "@/components/Badge";
import { categories, ebooks } from "@/data/mock";
import type { BookCategory } from "@/types/domain";

type SortKey = "terbaru" | "terlaris" | "rating";

function parseSort(v: string | null): SortKey {
  if (v === "terlaris" || v === "rating") return v;
  return "terbaru";
}

export default function Catalog() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") ?? "";
  const cat = (params.get("cat") ?? "") as BookCategory | "";
  const sort = parseSort(params.get("sort"));

  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const filtered = useMemo(() => {
    const qLower = q.trim().toLowerCase();
    let list = ebooks.slice();
    if (cat) list = list.filter((b) => b.category === cat);
    if (qLower) {
      list = list.filter((b) => {
        return (
          b.title.toLowerCase().includes(qLower) ||
          b.category.toLowerCase().includes(qLower) ||
          b.tags.some((t) => t.toLowerCase().includes(qLower))
        );
      });
    }
    if (sort === "rating") list.sort((a, b) => b.ratingAvg - a.ratingAvg);
    if (sort === "terlaris") list.sort((a, b) => b.ratingCount - a.ratingCount);
    if (sort === "terbaru")
      list.sort((a, b) => +new Date(b.publishedAtISO) - +new Date(a.publishedAtISO));
    return list;
  }, [cat, q, sort]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-2xl font-semibold tracking-tight text-ink md:text-3xl">
            Katalog
          </div>
          <div className="mt-2 text-sm text-muted">
            Pencarian cepat, filter kategori, dan rekomendasi berdasarkan minat.
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            className="md:hidden"
            onClick={() => setMobileFilterOpen((v) => !v)}
          >
            <Filter size={16} />
            Filter
          </Button>
          <select
            className="h-10 rounded-xl border border-border bg-white px-3 text-sm font-semibold text-ink outline-none"
            value={sort}
            onChange={(e) => {
              const next = new URLSearchParams(params);
              next.set("sort", e.target.value);
              setParams(next);
            }}
            aria-label="Urutkan"
          >
            <option value="terbaru">Terbaru</option>
            <option value="terlaris">Terlaris</option>
            <option value="rating">Rating tertinggi</option>
          </select>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-[280px_1fr]">
        <aside
          className={`space-y-4 rounded-2xl border border-border bg-white p-5 shadow-[0_1px_0_rgba(15,23,42,0.04)] ${
            mobileFilterOpen ? "block" : "hidden md:block"
          }`}
        >
          <div className="text-sm font-semibold text-ink">Pencarian</div>
          <div className="relative">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted">
              <Search size={16} />
            </span>
            <Input
              value={q}
              onChange={(e) => {
                const next = new URLSearchParams(params);
                const value = e.target.value;
                if (value) next.set("q", value);
                else next.delete("q");
                setParams(next);
              }}
              placeholder="Ketik judul / kategori…"
              className="pl-9"
            />
          </div>

          <div className="pt-2">
            <div className="text-sm font-semibold text-ink">Kategori</div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
                  !cat
                    ? "border-brand-2 bg-brand-2/10 text-brand-2"
                    : "border-border bg-white text-muted hover:bg-surface"
                }`}
                onClick={() => {
                  const next = new URLSearchParams(params);
                  next.delete("cat");
                  setParams(next);
                }}
              >
                Semua
              </button>
              {categories.map((c) => (
                <button
                  key={c}
                  type="button"
                  className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
                    cat === c
                      ? "border-brand-2 bg-brand-2/10 text-brand-2"
                      : "border-border bg-white text-muted hover:bg-surface"
                  }`}
                  onClick={() => {
                    const next = new URLSearchParams(params);
                    next.set("cat", c);
                    setParams(next);
                  }}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2">
            <div className="text-sm font-semibold text-ink">Filter cepat</div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className="rounded-full border border-border bg-white px-3 py-1 text-xs font-semibold text-muted transition hover:bg-surface"
                onClick={() => {
                  const next = new URLSearchParams(params);
                  next.set("sort", "terlaris");
                  setParams(next);
                }}
              >
                Best Seller
              </button>
              <button
                type="button"
                className="rounded-full border border-border bg-white px-3 py-1 text-xs font-semibold text-muted transition hover:bg-surface"
                onClick={() => {
                  const next = new URLSearchParams(params);
                  next.set("sort", "rating");
                  setParams(next);
                }}
              >
                Rating tinggi
              </button>
            </div>
          </div>
        </aside>

        <section className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            {q ? (
              <Badge tone="neutral">
                Pencarian: <span className="font-semibold text-ink">{q}</span>
              </Badge>
            ) : null}
            {cat ? (
              <Badge tone="neutral">
                Kategori: <span className="font-semibold text-ink">{cat}</span>
              </Badge>
            ) : null}
            <div className="ml-auto text-sm text-muted">{filtered.length} hasil</div>
          </div>

          {filtered.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((b) => (
                <BookCard key={b.id} ebook={b} />
              ))}
            </div>
          ) : (
            <div className="rounded-2xl border border-border bg-white p-6 text-sm text-muted">
              Belum ada e-book yang tersedia.
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
