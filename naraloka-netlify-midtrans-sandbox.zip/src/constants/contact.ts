export const supportWhatsAppNumber = "6281234567890";
export const supportWhatsAppDisplay = "+62 812-3456-7890";
export const supportWhatsAppUrl = `https://wa.me/${supportWhatsAppNumber}`;

export const supportEmail = "support@naraloka.app";
export const supportEmailUrl = `mailto:${supportEmail}`;
