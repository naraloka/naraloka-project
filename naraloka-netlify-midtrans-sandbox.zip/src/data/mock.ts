import type {
  Article,
  AuthorProfile,
  BookCategory,
  Ebook,
  Review,
  Testimonial,
} from "@/types/domain";
import { t2i } from "@/utils/image";

function makePages(seedTitle: string, pageCount: number) {
  const pages: string[] = [];
  for (let i = 1; i <= pageCount; i += 1) {
    pages.push(
      `${seedTitle}\n\nHalaman ${i}\n\n` +
        "Di atas kertas yang terasa hangat, kata-kata bergerak pelan—mengajakmu menunda dunia sejenak. " +
        "Bacaan ini dibuat untuk prototipe Naraloka: teks contoh yang memprioritaskan keterbacaan, spasi, dan ritme paragraf.\n\n" +
        "Tarik napas. Lanjutkan membaca saat siap."
    );
  }
  return pages;
}

export const categories: BookCategory[] = [
  "Novel",
  "Edukasi",
  "Motivasi",
  "Cerpen",
  "Komik Digital",
];

export const authors: AuthorProfile[] = [
  {
    id: "a-nara",
    displayName: "Nara Widya",
    bio: "Menulis novel realis dengan fokus pada karakter, kota, dan memori yang tumbuh perlahan.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian female author, soft natural light, clean background, editorial style, ultra realistic, high detail",
      "square"
    ),
    followerCount: 28450,
  },
  {
    id: "a-bima",
    displayName: "Bima Arkatama",
    bio: "Penulis nonfiksi edukasi yang menyukai penjelasan ringkas, ilustrasi konsep, dan contoh nyata.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian male author, modern minimal studio lighting, clean background, ultra realistic, high detail",
      "square"
    ),
    followerCount: 17320,
  },
  {
    id: "a-senja",
    displayName: "Senja Aksara",
    bio: "Cerpenis yang menulis kisah-kisah pendek: sunyi, lucu, dan sering berakhir dengan twist lembut.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian young adult writer, soft warm light, minimal background, ultra realistic",
      "square"
    ),
    followerCount: 21910,
  },
  {
    id: "a-raka",
    displayName: "Raka Pustaka",
    bio: "Komikus digital dengan gaya garis tegas, komedi observasi, dan panel yang rapi.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian comic artist, crisp lighting, clean background, ultra realistic",
      "square"
    ),
    followerCount: 33280,
  },
];

export const ebooks: Ebook[] = [];

export const reviews: Review[] = [];

export const testimonials: Testimonial[] = [];

export const articles: Article[] = [
  {
    id: "ar1",
    title: "Cara Memilih Bacaan yang Cocok untuk Mood Hari Ini",
    excerpt:
      "Mood sering menentukan gaya baca. Coba mulai dari durasi, tema, dan energi tulisan.",
    publishedAtISO: "2026-06-07T07:00:00.000Z",
    tags: ["Rekomendasi", "Tips Membaca"],
  },
  {
    id: "ar2",
    title: "Mengenal Highlight & Catatan: Membaca yang Tidak Mudah Lupa",
    excerpt:
      "Highlight yang baik itu ringkas. Catatan yang baik itu menyambungkan ide ke pengalamanmu.",
    publishedAtISO: "2026-06-04T07:00:00.000Z",
    tags: ["Edukasi", "Produktivitas"],
  },
  {
    id: "ar3",
    title: "Kenapa Membership Edukasi Cocok untuk Belajar Mandiri",
    excerpt:
      "Akses bacaan yang tepat, ritme belajar yang fleksibel, dan progress yang terasa.",
    publishedAtISO: "2026-05-29T07:00:00.000Z",
    tags: ["Membership", "Edukasi"],
  },
];
