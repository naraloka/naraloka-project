import { useMemo, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Home, LayoutDashboard, Library, Search, User } from "lucide-react";
import { cn } from "@/lib/utils";
import Input from "@/components/Input";
import Badge from "@/components/Badge";
import { supportEmail, supportEmailUrl, supportWhatsAppDisplay, supportWhatsAppUrl } from "@/constants/contact";
import { useSessionStore } from "@/stores/sessionStore";
import type { MembershipPlan, UserRole } from "@/types/domain";

const navItems = [
  { to: "/", label: "Beranda", icon: Home },
  { to: "/katalog", label: "Katalog", icon: Search },
  { to: "/perpustakaan", label: "Perpustakaan", icon: Library },
  { to: "/penulis", label: "Penulis", icon: User },
];

export default function AppShell() {
  const location = useLocation();
  const navigate = useNavigate();
  const user = useSessionStore((s) => s.user);
  const loginDemo = useSessionStore((s) => s.loginDemo);
  const setMembershipPlan = useSessionStore((s) => s.setMembershipPlan);

  const [query, setQuery] = useState("");
  const showBottomNav = useMemo(() => {
    const path = location.pathname;
    if (path.startsWith("/baca/")) return false;
    if (path.startsWith("/admin")) return false;
    return true;
  }, [location.pathname]);

  const role = user?.role ?? "READER";
  const membershipPlan = user?.membershipPlan ?? "FREE";

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
          <Link to="/" className="group flex items-center gap-2">
            <span className="inline-flex h-9 w-9 items-center justify-center overflow-hidden rounded-2xl border border-border bg-white shadow-soft">
              <img src="/naraloka-mark.svg" alt="Naraloka" className="h-full w-full object-cover" />
            </span>
            <div className="leading-tight">
              <div className="text-sm font-semibold tracking-tight text-ink group-hover:text-brand">
                Naraloka
              </div>
              <div className="text-[11px] text-muted">Baca. Tulis. Terkoneksi.</div>
            </div>
          </Link>

          <form
            className="hidden flex-1 md:block"
            onSubmit={(e) => {
              e.preventDefault();
              const q = query.trim();
              navigate(q ? `/katalog?q=${encodeURIComponent(q)}` : "/katalog");
            }}
          >
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari judul, penulis, atau kategori…"
              className="h-11 rounded-2xl"
            />
          </form>

          <div className="ml-auto hidden items-center gap-3 md:flex">
            <div className="flex items-center gap-2 rounded-2xl border border-border bg-white px-3 py-2">
              <span className="text-xs font-medium text-muted">Mode</span>
              <select
                className="bg-transparent text-sm font-semibold text-ink outline-none"
                value={role}
                onChange={(e) => loginDemo(e.target.value as UserRole)}
                aria-label="Mode pengguna"
              >
                <option value="READER">Pembaca</option>
                <option value="AUTHOR">Penulis</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>

            {role === "READER" ? (
              <div className="flex items-center gap-2 rounded-2xl border border-border bg-white px-3 py-2">
                <span className="text-xs font-medium text-muted">Paket</span>
                <select
                  className="bg-transparent text-sm font-semibold text-ink outline-none"
                  value={membershipPlan}
                  onChange={(e) => setMembershipPlan(e.target.value as MembershipPlan)}
                  aria-label="Paket membership"
                >
                  <option value="FREE">Gratis</option>
                  <option value="PREMIUM">Premium</option>
                  <option value="EDU">Edukasi</option>
                </select>
              </div>
            ) : (
              <Badge tone="brand">{role === "AUTHOR" ? "Portal Penulis" : "Admin"}</Badge>
            )}

            {role === "ADMIN" ? (
              <NavLink
                to="/admin"
                className={({ isActive }) =>
                  cn(
                    "inline-flex items-center gap-2 rounded-2xl border border-border bg-white px-3 py-2 text-sm font-semibold text-ink transition hover:bg-surface",
                    isActive && "border-brand-2 bg-brand-2/10 text-brand-2"
                  )
                }
              >
                <LayoutDashboard size={16} />
                Dashboard
              </NavLink>
            ) : null}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24 pt-6 md:pb-10">
        <Outlet />
      </main>

      {showBottomNav ? (
        <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-white/90 backdrop-blur md:hidden">
          <div className="mx-auto grid max-w-6xl grid-cols-4 px-2 py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "flex flex-col items-center justify-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-medium text-muted transition",
                      isActive && "bg-brand-2/10 text-brand-2"
                    )
                  }
                >
                  <Icon size={18} />
                  {item.label}
                </NavLink>
              );
            })}
          </div>
        </nav>
      ) : null}

      <footer className="border-t border-border/60 bg-white/60">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="text-sm font-semibold text-ink">Naraloka</div>
            <div className="mt-1 text-xs text-muted">
              Prototipe UI/UX. Pembayaran & integrasi eksternal masih simulasi.
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs text-muted">
            <a href={supportWhatsAppUrl} className="hover:text-brand">
              WhatsApp CS ({supportWhatsAppDisplay})
            </a>
            <span className="h-1 w-1 rounded-full bg-border" />
            <a href={supportEmailUrl} className="hover:text-brand">
              {supportEmail}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
