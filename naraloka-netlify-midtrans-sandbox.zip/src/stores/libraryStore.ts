import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Bookmark, Highlight, LibraryItem } from "@/types/domain";
import { useSessionStore } from "@/stores/sessionStore";

type UserScoped<T> = Record<string, T>;

type LibraryState = {
  libraryByUser: UserScoped<Record<string, LibraryItem>>;
  wishlistByUser: UserScoped<Record<string, true>>;
  bookmarksByUser: UserScoped<Record<string, Bookmark[]>>;
  highlightsByUser: UserScoped<Record<string, Highlight[]>>;
  addToLibrary: (ebookId: string, totalPages: number) => void;
  markOwned: (ebookId: string, totalPages: number) => void;
  toggleDownloaded: (ebookId: string, totalPages: number) => void;
  updateProgress: (ebookId: string, page: number, totalPages: number) => void;
  toggleWishlist: (ebookId: string) => void;
  toggleBookmark: (ebookId: string, page: number) => void;
  addHighlight: (ebookId: string, page: number, text: string) => void;
  setHighlightNote: (highlightId: string, note: string) => void;
  removeHighlight: (highlightId: string) => void;
};

function nowIso() {
  return new Date().toISOString();
}

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
}

function userId() {
  return useSessionStore.getState().user?.id ?? "guest";
}

function ensureMap<T>(map: UserScoped<T>, key: string, make: () => T) {
  if (map[key]) return map[key];
  const next = make();
  map[key] = next;
  return next;
}

export const useLibraryStore = create<LibraryState>()(
  persist(
    (set, get) => ({
      libraryByUser: {},
      wishlistByUser: {},
      bookmarksByUser: {},
      highlightsByUser: {},

      addToLibrary: (ebookId, totalPages) => {
        set((state) => {
          const uidKey = userId();
          const userLib = ensureMap(state.libraryByUser, uidKey, () => ({}));
          if (!userLib[ebookId]) {
            userLib[ebookId] = {
              userId: uidKey,
              ebookId,
              owned: false,
              downloaded: false,
              lastReadAtISO: nowIso(),
              progress: { currentPage: 1, totalPages },
            };
          }
          return { ...state };
        });
      },

      markOwned: (ebookId, totalPages) => {
        set((state) => {
          const uidKey = userId();
          const userLib = ensureMap(state.libraryByUser, uidKey, () => ({}));
          userLib[ebookId] = {
            userId: uidKey,
            ebookId,
            owned: true,
            downloaded: userLib[ebookId]?.downloaded ?? false,
            lastReadAtISO: nowIso(),
            progress: userLib[ebookId]?.progress ?? { currentPage: 1, totalPages },
          };
          return { ...state };
        });
      },

      toggleDownloaded: (ebookId, totalPages) => {
        set((state) => {
          const uidKey = userId();
          const userLib = ensureMap(state.libraryByUser, uidKey, () => ({}));
          const current = userLib[ebookId] ?? {
            userId: uidKey,
            ebookId,
            owned: false,
            downloaded: false,
            progress: { currentPage: 1, totalPages },
          };
          userLib[ebookId] = {
            ...current,
            downloaded: !current.downloaded,
            lastReadAtISO: nowIso(),
          };
          return { ...state };
        });
      },

      updateProgress: (ebookId, page, totalPages) => {
        set((state) => {
          const uidKey = userId();
          const userLib = ensureMap(state.libraryByUser, uidKey, () => ({}));
          const current = userLib[ebookId] ?? {
            userId: uidKey,
            ebookId,
            owned: false,
            downloaded: false,
            progress: { currentPage: 1, totalPages },
          };
          userLib[ebookId] = {
            ...current,
            lastReadAtISO: nowIso(),
            progress: { currentPage: page, totalPages },
          };
          return { ...state };
        });
      },

      toggleWishlist: (ebookId) => {
        set((state) => {
          const uidKey = userId();
          const wish = ensureMap(state.wishlistByUser, uidKey, () => ({}));
          if (wish[ebookId]) {
            const next = { ...wish };
            delete next[ebookId];
            state.wishlistByUser[uidKey] = next;
          } else {
            state.wishlistByUser[uidKey] = { ...wish, [ebookId]: true };
          }
          return { ...state };
        });
      },

      toggleBookmark: (ebookId, page) => {
        set((state) => {
          const uidKey = userId();
          const map = ensureMap(state.bookmarksByUser, uidKey, () => ({}));
          const current = map[ebookId] ?? [];
          const existing = current.find((b) => b.page === page);
          map[ebookId] = existing
            ? current.filter((b) => b.page !== page)
            : [
                ...current,
                { id: uid("bm"), userId: uidKey, ebookId, page, createdAtISO: nowIso() },
              ];
          return { ...state };
        });
      },

      addHighlight: (ebookId, page, text) => {
        set((state) => {
          const uidKey = userId();
          const map = ensureMap(state.highlightsByUser, uidKey, () => ({}));
          const current = map[ebookId] ?? [];
          map[ebookId] = [
            ...current,
            { id: uid("hl"), userId: uidKey, ebookId, page, text, createdAtISO: nowIso() },
          ];
          return { ...state };
        });
      },

      setHighlightNote: (highlightId, note) => {
        set((state) => {
          const uidKey = userId();
          const map = ensureMap(state.highlightsByUser, uidKey, () => ({}));
          for (const ebookId of Object.keys(map)) {
            const list = map[ebookId] ?? [];
            const idx = list.findIndex((h) => h.id === highlightId);
            if (idx >= 0) {
              const next = [...list];
              next[idx] = { ...next[idx], note };
              map[ebookId] = next;
              break;
            }
          }
          return { ...state };
        });
      },

      removeHighlight: (highlightId) => {
        set((state) => {
          const uidKey = userId();
          const map = ensureMap(state.highlightsByUser, uidKey, () => ({}));
          for (const ebookId of Object.keys(map)) {
            const list = map[ebookId] ?? [];
            if (list.some((h) => h.id === highlightId)) {
              map[ebookId] = list.filter((h) => h.id !== highlightId);
              break;
            }
          }
          return { ...state };
        });
      },
    }),
    { name: "naraloka_library_v1" }
  )
);

export function selectUserLibrary(ebookId: string) {
  const uidKey = userId();
  return (get().libraryByUser[uidKey] ?? {})[ebookId] ?? null;
  function get() {
    return useLibraryStore.getState();
  }
}

