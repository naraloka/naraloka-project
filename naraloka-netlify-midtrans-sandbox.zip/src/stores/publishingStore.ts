import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { BookCategory } from "@/types/domain";

export type ManuscriptStatus = "DRAFT" | "SUBMITTED" | "APPROVED" | "REJECTED";

export type Manuscript = {
  id: string;
  authorId: string;
  title: string;
  category: BookCategory;
  fileName: string;
  submittedAtISO: string;
  status: ManuscriptStatus;
  adminNote?: string;
};

export type RoyaltyConfig = {
  platformCommissionPct: number;
  authorRoyaltyPct: number;
};

type PublishingState = {
  manuscripts: Manuscript[];
  royalty: RoyaltyConfig;
  submitManuscript: (input: Omit<Manuscript, "id" | "submittedAtISO" | "status">) => void;
  setCommissionPct: (platformCommissionPct: number) => void;
  approve: (id: string) => void;
  reject: (id: string, adminNote: string) => void;
};

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
}

export const usePublishingStore = create<PublishingState>()(
  persist(
    (set, get) => ({
      manuscripts: [
        {
          id: "ms_1",
          authorId: "a-nara",
          title: "Fragmen di Stasiun Tua",
          category: "Cerpen",
          fileName: "fragmen-di-stasiun-tua.docx",
          submittedAtISO: "2026-06-02T07:00:00.000Z",
          status: "SUBMITTED",
        },
      ],
      royalty: { platformCommissionPct: 20, authorRoyaltyPct: 80 },
      submitManuscript: (input) => {
        set((state) => ({
          manuscripts: [
            {
              id: uid("ms"),
              ...input,
              submittedAtISO: new Date().toISOString(),
              status: "SUBMITTED",
            },
            ...state.manuscripts,
          ],
        }));
      },
      setCommissionPct: (platformCommissionPct) => {
        const pct = Math.min(60, Math.max(0, Math.round(platformCommissionPct)));
        set({ royalty: { platformCommissionPct: pct, authorRoyaltyPct: 100 - pct } });
      },
      approve: (id) => {
        set((state) => ({
          manuscripts: state.manuscripts.map((m) => (m.id === id ? { ...m, status: "APPROVED", adminNote: undefined } : m)),
        }));
      },
      reject: (id, adminNote) => {
        set((state) => ({
          manuscripts: state.manuscripts.map((m) => (m.id === id ? { ...m, status: "REJECTED", adminNote } : m)),
        }));
      },
    }),
    { name: "naraloka_publishing_v1" }
  )
);

