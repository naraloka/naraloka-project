import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { MembershipPlan, UserProfile, UserRole } from "@/types/domain";

type SessionState = {
  user: UserProfile | null;
  loginDemo: (role: UserRole) => void;
  logout: () => void;
  setMembershipPlan: (plan: MembershipPlan) => void;
};

const demoUserBase = {
  id: "u-demo",
  name: "Pengguna Demo",
  email: "demo@naraloka.app",
} as const;

export const useSessionStore = create<SessionState>()(
  persist(
    (set, get) => ({
      user: {
        ...demoUserBase,
        role: "READER",
        membershipPlan: "FREE",
      },
      loginDemo: (role) => {
        const current = get().user;
        set({
          user: {
            ...(current ?? demoUserBase),
            role,
            membershipPlan: current?.membershipPlan ?? "FREE",
          },
        });
      },
      logout: () => {
        set({ user: null });
      },
      setMembershipPlan: (plan) => {
        const current = get().user ?? {
          ...demoUserBase,
          role: "READER" as UserRole,
          membershipPlan: "FREE" as MembershipPlan,
        };
        set({ user: { ...current, membershipPlan: plan } });
      },
    }),
    { name: "naraloka_session_v1" }
  )
);

