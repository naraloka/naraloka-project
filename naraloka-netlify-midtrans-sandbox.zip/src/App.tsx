import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AppShell from "@/components/AppShell";
import AdminDashboard from "@/pages/AdminDashboard";
import AuthorPortal from "@/pages/AuthorPortal";
import Catalog from "@/pages/Catalog";
import Checkout from "@/pages/Checkout";
import EbookDetail from "@/pages/EbookDetail";
import Home from "@/pages/Home";
import LibraryPage from "@/pages/Library";
import Login from "@/pages/Login";
import Reader from "@/pages/Reader";
import Subscription from "@/pages/Subscription";
import Wishlist from "@/pages/Wishlist";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<Home />} />
          <Route path="/katalog" element={<Catalog />} />
          <Route path="/ebook/:ebookId" element={<EbookDetail />} />
          <Route path="/baca/:ebookId" element={<Reader />} />
          <Route path="/perpustakaan" element={<LibraryPage />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/langganan" element={<Subscription />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/penulis" element={<AuthorPortal />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="*"
            element={
              <div className="rounded-2xl border border-border bg-white p-6 text-center">
                <div className="text-sm font-semibold text-ink">Halaman tidak ditemukan</div>
                <div className="mt-1 text-sm text-muted">
                  Coba kembali ke <a className="font-semibold text-brand hover:underline" href="/">beranda</a>.
                </div>
              </div>
            }
          />
        </Route>
      </Routes>
    </Router>
  );
}
