# Naraloka (Book Platform) — Prototipe UI/UX

Prototipe platform e-book kerja sama penulis: Beranda, Katalog, Detail E-book, Reader (bookmark/highlight/catatan/offline simulasi), Portal Penulis, dan Dashboard Admin.

## Menjalankan Lokal

```bash
npm install
npm run dev
```

## Konfigurasi Midtrans

1. Salin file `.env.example` menjadi `.env`
2. Isi kredensial Midtrans:

```bash
VITE_MIDTRANS_ENV=sandbox
VITE_MIDTRANS_CLIENT_KEY=SB-Mid-client-xxxxxxxxxxxx
MIDTRANS_SERVER_KEY=SB-Mid-server-xxxxxxxxxxxx
```

3. Jalankan aplikasi:

```bash
npm install
npm run dev
```

Catatan:
- Checkout memanggil endpoint `/api/midtrans/token`
- Saat `npm run dev`, endpoint Midtrans juga aktif lewat middleware Vite
- Untuk deploy di Vercel, tambahkan env yang sama di Project Settings -> Environment Variables

## Deploy Publik (Vercel)

1. Buat repository GitHub baru, lalu push project ini.
2. Buka Vercel → **New Project** → Import repo GitHub.
3. Pastikan pengaturan berikut:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Environment Variables:
     - `VITE_MIDTRANS_ENV`
     - `VITE_MIDTRANS_CLIENT_KEY`
     - `MIDTRANS_SERVER_KEY`
4. Klik **Deploy** → Vercel akan memberi URL publik.

Catatan:
- File [vercel.json](./vercel.json) sudah disiapkan agar routing React Router tetap berjalan saat refresh URL.

## Deploy Publik (Netlify)

1. Import repository ke Netlify
2. Build setting:
   - Build command: `npm run build`
   - Publish directory: `dist`
3. Tambahkan environment variables:
   - `VITE_MIDTRANS_ENV`
   - `VITE_MIDTRANS_CLIENT_KEY`
   - `MIDTRANS_SERVER_KEY`

Catatan:
- File [netlify.toml](./netlify.toml) sudah menyiapkan:
  - redirect SPA `/* -> /index.html`
  - redirect endpoint `/api/midtrans/token` ke Netlify Function
