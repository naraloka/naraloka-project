function normalizeEnvironment(value) {
  return String(value || "sandbox").toLowerCase() === "production" ? "production" : "sandbox";
}

export function getMidtransConfig(env = process.env) {
  const environment = normalizeEnvironment(env.VITE_MIDTRANS_ENV || env.MIDTRANS_ENV);
  const clientKey = env.VITE_MIDTRANS_CLIENT_KEY || env.MIDTRANS_CLIENT_KEY || "";
  const serverKey = env.MIDTRANS_SERVER_KEY || "";

  return {
    environment,
    clientKey,
    serverKey,
    snapScriptUrl:
      environment === "production"
        ? "https://app.midtrans.com/snap/snap.js"
        : "https://app.sandbox.midtrans.com/snap/snap.js",
    transactionApiUrl:
      environment === "production"
        ? "https://app.midtrans.com/snap/v1/transactions"
        : "https://app.sandbox.midtrans.com/snap/v1/transactions",
  };
}

function toOrderId(seed) {
  const base = String(seed || `NRL-${Date.now()}`)
    .replace(/[^a-zA-Z0-9-_]/g, "-")
    .slice(0, 48);
  return `${base}-${Date.now()}`;
}

export async function createMidtransTransaction(payload = {}, env = process.env) {
  const config = getMidtransConfig(env);

  if (!config.serverKey) {
    const error = new Error("MIDTRANS_SERVER_KEY belum diatur.");
    error.statusCode = 500;
    throw error;
  }

  if (!config.clientKey) {
    const error = new Error("VITE_MIDTRANS_CLIENT_KEY belum diatur.");
    error.statusCode = 500;
    throw error;
  }

  const buyerName = String(payload.buyerName || "").trim();
  const buyerEmail = String(payload.buyerEmail || "").trim();
  const buyerWhatsApp = String(payload.buyerWhatsApp || "").trim();
  const amount = Number(payload.amount);
  const itemName = String(payload.itemName || "Pembayaran Naraloka").trim();
  const orderId = toOrderId(payload.orderCode || "NRL");

  if (!buyerName || !buyerEmail || !buyerWhatsApp || !amount || amount <= 0) {
    const error = new Error("Data pembayaran tidak lengkap.");
    error.statusCode = 400;
    throw error;
  }

  const requestPayload = {
    transaction_details: {
      order_id: orderId,
      gross_amount: Math.round(amount),
    },
    customer_details: {
      first_name: buyerName,
      email: buyerEmail,
      phone: buyerWhatsApp,
    },
    item_details: [
      {
        id: String(payload.itemId || "naraloka-checkout"),
        price: Math.round(amount),
        quantity: 1,
        name: itemName,
      },
    ],
    callbacks: payload.finishUrl
      ? {
          finish: payload.finishUrl,
        }
      : undefined,
  };

  const response = await fetch(config.transactionApiUrl, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Basic ${Buffer.from(`${config.serverKey}:`).toString("base64")}`,
    },
    body: JSON.stringify(requestPayload),
  });

  if (!response.ok) {
    const text = await response.text();
    const error = new Error(text || "Gagal membuat transaksi Midtrans.");
    error.statusCode = response.status;
    throw error;
  }

  const data = await response.json();

  return {
    token: data.token,
    redirectUrl: data.redirect_url,
    orderId,
    environment: config.environment,
    clientKey: config.clientKey,
    snapScriptUrl: config.snapScriptUrl,
  };
}
