import type {
  Article,
  AuthorProfile,
  BookCategory,
  Ebook,
  Review,
  Testimonial,
} from "@/types/domain";
import { t2i } from "@/utils/image";

function makePages(seedTitle: string, pageCount: number) {
  const pages: string[] = [];
  for (let i = 1; i <= pageCount; i += 1) {
    pages.push(
      `${seedTitle}\n\nHalaman ${i}\n\n` +
        "Di atas kertas yang terasa hangat, kata-kata bergerak pelan—mengajakmu menunda dunia sejenak. " +
        "Bacaan ini dibuat untuk prototipe Naraloka: teks contoh yang memprioritaskan keterbacaan, spasi, dan ritme paragraf.\n\n" +
        "Tarik napas. Lanjutkan membaca saat siap."
    );
  }
  return pages;
}

export const categories: BookCategory[] = [
  "Novel",
  "Edukasi",
  "Motivasi",
  "Cerpen",
  "Komik Digital",
];

export const authors: AuthorProfile[] = [
  {
    id: "a-nara",
    displayName: "Nara Widya",
    bio: "Menulis novel realis dengan fokus pada karakter, kota, dan memori yang tumbuh perlahan.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian female author, soft natural light, clean background, editorial style, ultra realistic, high detail",
      "square"
    ),
    followerCount: 28450,
  },
  {
    id: "a-bima",
    displayName: "Bima Arkatama",
    bio: "Penulis nonfiksi edukasi yang menyukai penjelasan ringkas, ilustrasi konsep, dan contoh nyata.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian male author, modern minimal studio lighting, clean background, ultra realistic, high detail",
      "square"
    ),
    followerCount: 17320,
  },
  {
    id: "a-senja",
    displayName: "Senja Aksara",
    bio: "Cerpenis yang menulis kisah-kisah pendek: sunyi, lucu, dan sering berakhir dengan twist lembut.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian young adult writer, soft warm light, minimal background, ultra realistic",
      "square"
    ),
    followerCount: 21910,
  },
  {
    id: "a-raka",
    displayName: "Raka Pustaka",
    bio: "Komikus digital dengan gaya garis tegas, komedi observasi, dan panel yang rapi.",
    avatarUrl: t2i(
      "Portrait photo of an Indonesian comic artist, crisp lighting, clean background, ultra realistic",
      "square"
    ),
    followerCount: 33280,
  },
];

export const ebooks: Ebook[] = [
  {
    id: "e-aurora",
    title: "Aurora di Ujung Kota",
    authorId: "a-nara",
    coverUrl: t2i(
      "Minimalist book cover, navy blue and white, abstract city skyline at night, subtle grain, premium editorial typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Novel",
    description:
      "Sebuah novel tentang kota yang tidak pernah benar-benar tidur, dan dua orang yang belajar mengingat tanpa terjebak masa lalu.",
    ratingAvg: 4.6,
    ratingCount: 12480,
    priceCents: 69000 * 100,
    access: "PAID",
    isBestSeller: true,
    isFeatured: true,
    publishedAtISO: "2026-04-12T07:00:00.000Z",
    pageCount: 248,
    tags: ["Urban", "Romantis", "Coming-of-age"],
    previewPages: makePages("Aurora di Ujung Kota (Preview)", 6),
    pages: makePages("Aurora di Ujung Kota", 248),
  },
  {
    id: "e-catatan-fokus",
    title: "Catatan Fokus: 21 Hari Membaca Lebih Dalam",
    authorId: "a-bima",
    coverUrl: t2i(
      "Minimalist book cover for productivity education, white background, navy geometric shapes, clean layout, premium typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Edukasi",
    description:
      "Panduan praktis untuk membangun kebiasaan membaca, membuat catatan yang berguna, dan mengingat ide tanpa stres.",
    ratingAvg: 4.4,
    ratingCount: 8920,
    priceCents: 0,
    access: "MEMBERSHIP",
    requiredPlan: "PREMIUM",
    isBestSeller: false,
    isFeatured: true,
    publishedAtISO: "2026-05-05T07:00:00.000Z",
    pageCount: 132,
    tags: ["Belajar", "Produktivitas", "Catatan"],
    previewPages: makePages("Catatan Fokus (Preview)", 5),
    pages: makePages("Catatan Fokus", 132),
  },
  {
    id: "e-langkah-kecil",
    title: "Langkah Kecil, Hasil Besar",
    authorId: "a-bima",
    coverUrl: t2i(
      "Minimalist motivational book cover, white and light gray, navy accent line, calm modern typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Motivasi",
    description:
      "Motivasi tanpa teriak: strategi mikro yang konsisten untuk membawa perubahan yang terasa nyata.",
    ratingAvg: 4.7,
    ratingCount: 15630,
    priceCents: 59000 * 100,
    access: "PAID",
    isBestSeller: true,
    isFeatured: false,
    publishedAtISO: "2026-02-18T07:00:00.000Z",
    pageCount: 196,
    tags: ["Kebiasaan", "Mindset", "Praktis"],
    previewPages: makePages("Langkah Kecil, Hasil Besar (Preview)", 6),
    pages: makePages("Langkah Kecil, Hasil Besar", 196),
  },
  {
    id: "e-senjay",
    title: "Senja yang Tidak Pernah Sama",
    authorId: "a-nara",
    coverUrl: t2i(
      "Minimalist romance novel book cover, navy and warm gray, abstract sunset gradient, editorial typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Novel",
    description:
      "Kisah dua sahabat yang bertemu lagi setelah sepuluh tahun, dan menyadari ada hal-hal yang harus dibicarakan sekarang.",
    ratingAvg: 4.3,
    ratingCount: 6430,
    priceCents: 49000 * 100,
    access: "PAID",
    isBestSeller: false,
    isFeatured: false,
    publishedAtISO: "2026-03-22T07:00:00.000Z",
    pageCount: 212,
    tags: ["Drama", "Persahabatan", "Romantis"],
    previewPages: makePages("Senja yang Tidak Pernah Sama (Preview)", 5),
    pages: makePages("Senja yang Tidak Pernah Sama", 212),
  },
  {
    id: "e-cerpen-01",
    title: "Kumpulan Cerpen: Pintu yang Salah",
    authorId: "a-senja",
    coverUrl: t2i(
      "Minimalist short story collection book cover, white background, navy door silhouette, modern typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Cerpen",
    description:
      "12 cerita pendek yang berawal biasa saja, lalu berbelok pelan ke arah yang tidak kamu duga.",
    ratingAvg: 4.5,
    ratingCount: 5080,
    priceCents: 39000 * 100,
    access: "PAID",
    isBestSeller: false,
    isFeatured: true,
    publishedAtISO: "2026-01-09T07:00:00.000Z",
    pageCount: 104,
    tags: ["Twist", "Ringan", "Cepat dibaca"],
    previewPages: makePages("Pintu yang Salah (Preview)", 4),
    pages: makePages("Pintu yang Salah", 104),
  },
  {
    id: "e-komik-01",
    title: "Komik Digital: Hari-hari di Kafe Pojok",
    authorId: "a-raka",
    coverUrl: t2i(
      "Modern minimalist comic cover, clean white, navy line art of a small cafe, bold title typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Komik Digital",
    description:
      "Komik slice-of-life tentang barista, pelanggan, dan percakapan kecil yang ternyata menyembuhkan.",
    ratingAvg: 4.8,
    ratingCount: 20340,
    priceCents: 0,
    access: "OPEN",
    isBestSeller: true,
    isFeatured: false,
    publishedAtISO: "2026-05-28T07:00:00.000Z",
    pageCount: 86,
    tags: ["Komedi", "Slice of life", "Visual"],
    previewPages: makePages("Hari-hari di Kafe Pojok (Preview)", 6),
    pages: makePages("Hari-hari di Kafe Pojok", 86),
  },
  {
    id: "e-edukasi-01",
    title: "Edukasi Ringkas: Finansial untuk Pemula",
    authorId: "a-bima",
    coverUrl: t2i(
      "Minimalist education book cover about personal finance, white background, navy charts, clean grid, premium typography, ultra high resolution",
      "portrait_4_3"
    ),
    category: "Edukasi",
    description:
      "Konsep finansial dasar dengan contoh sehari-hari: tabungan, dana darurat, hutang, dan investasi.",
    ratingAvg: 4.2,
    ratingCount: 3290,
    priceCents: 0,
    access: "MEMBERSHIP",
    requiredPlan: "EDU",
    isBestSeller: false,
    isFeatured: false,
    publishedAtISO: "2026-06-01T07:00:00.000Z",
    pageCount: 168,
    tags: ["Finansial", "Edukasi", "Pemula"],
    previewPages: makePages("Finansial untuk Pemula (Preview)", 5),
    pages: makePages("Finansial untuk Pemula", 168),
  },
];

export const reviews: Review[] = [
  {
    id: "r1",
    ebookId: "e-aurora",
    userId: "u-demo",
    rating: 5,
    comment:
      "Teksnya enak, layout bersih. Aku suka preview-nya dan fitur highlight yang rapi.",
    createdAtISO: "2026-05-30T07:00:00.000Z",
  },
  {
    id: "r2",
    ebookId: "e-aurora",
    userId: "u-demo2",
    rating: 4,
    comment:
      "Atmosfer kota malamnya terasa. Pengalaman membaca mirip perangkat e-reader.",
    createdAtISO: "2026-05-18T07:00:00.000Z",
  },
  {
    id: "r3",
    ebookId: "e-komik-01",
    userId: "u-demo3",
    rating: 5,
    comment: "Komiknya ringan, panel rapi. Bagus buat bacaan selingan.",
    createdAtISO: "2026-06-03T07:00:00.000Z",
  },
];

export const testimonials: Testimonial[] = [
  {
    id: "t1",
    name: "Alya",
    roleLabel: "Pembaca Premium",
    rating: 5,
    quote:
      "Naraloka terasa cepat dan bersih. Aku bisa pindah perangkat tanpa kehilangan progress bacaan.",
  },
  {
    id: "t2",
    name: "Dimas",
    roleLabel: "Penulis",
    rating: 5,
    quote:
      "Dashboard royalti jelas. Proses pengajuan kerja sama juga rapi dan tidak bikin bingung.",
  },
  {
    id: "t3",
    name: "Nita",
    roleLabel: "Pembaca Edukasi",
    rating: 4,
    quote:
      "Filter kategori dan rekomendasinya membantu. Fitur catatan bikin belajar lebih terstruktur.",
  },
];

export const articles: Article[] = [
  {
    id: "ar1",
    title: "Cara Memilih Bacaan yang Cocok untuk Mood Hari Ini",
    excerpt:
      "Mood sering menentukan gaya baca. Coba mulai dari durasi, tema, dan energi tulisan.",
    publishedAtISO: "2026-06-07T07:00:00.000Z",
    tags: ["Rekomendasi", "Tips Membaca"],
  },
  {
    id: "ar2",
    title: "Mengenal Highlight & Catatan: Membaca yang Tidak Mudah Lupa",
    excerpt:
      "Highlight yang baik itu ringkas. Catatan yang baik itu menyambungkan ide ke pengalamanmu.",
    publishedAtISO: "2026-06-04T07:00:00.000Z",
    tags: ["Edukasi", "Produktivitas"],
  },
  {
    id: "ar3",
    title: "Kenapa Membership Edukasi Cocok untuk Belajar Mandiri",
    excerpt:
      "Akses bacaan yang tepat, ritme belajar yang fleksibel, dan progress yang terasa.",
    publishedAtISO: "2026-05-29T07:00:00.000Z",
    tags: ["Membership", "Edukasi"],
  },
];
