import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Bookmark, BookOpenText, Check, Heart, ShoppingBag } from "lucide-react";
import Badge from "@/components/Badge";
import BookCard from "@/components/BookCard";
import Button from "@/components/Button";
import RatingStars from "@/components/RatingStars";
import { authors, ebooks, reviews as allReviews } from "@/data/mock";
import { cn } from "@/lib/utils";
import { useLibraryStore } from "@/stores/libraryStore";
import { useSessionStore } from "@/stores/sessionStore";
import type { Review } from "@/types/domain";
import { formatIdrFromCents } from "@/utils/format";

function hasAccess(params: {
  owned: boolean;
  membershipPlan: "FREE" | "PREMIUM" | "EDU";
  access: "OPEN" | "MEMBERSHIP" | "PAID";
  requiredPlan?: "FREE" | "PREMIUM" | "EDU";
}) {
  const { owned, membershipPlan, access, requiredPlan } = params;
  if (access === "OPEN") return true;
  if (access === "PAID") return owned;
  if (access === "MEMBERSHIP") {
    if (!requiredPlan) return membershipPlan !== "FREE";
    return membershipPlan === requiredPlan || membershipPlan === "PREMIUM";
  }
  return false;
}

export default function EbookDetail() {
  const { ebookId } = useParams();
  const navigate = useNavigate();

  const user = useSessionStore((s) => s.user);
  const membershipPlan = user?.membershipPlan ?? "FREE";
  const uid = user?.id ?? "guest";

  const markOwned = useLibraryStore((s) => s.markOwned);
  const addToLibrary = useLibraryStore((s) => s.addToLibrary);
  const toggleWishlist = useLibraryStore((s) => s.toggleWishlist);
  const library = useLibraryStore((s) => s.libraryByUser);
  const wishlist = useLibraryStore((s) => s.wishlistByUser);

  const ebook = ebooks.find((b) => b.id === ebookId);
  const author = authors.find((a) => a.id === ebook?.authorId);

  const owned = Boolean(library[uid]?.[ebook?.id ?? ""]?.owned);
  const allowed = ebook
    ? hasAccess({
        owned,
        membershipPlan,
        access: ebook.access,
        requiredPlan: ebook.requiredPlan,
      })
    : false;

  const isWishlisted = ebook ? Boolean(wishlist[uid]?.[ebook.id]) : false;

  const similar = useMemo(() => {
    if (!ebook) return [];
    return ebooks
      .filter((b) => b.id !== ebook.id && (b.category === ebook.category || b.authorId === ebook.authorId))
      .slice(0, 6);
  }, [ebook]);

  const initialReviews = useMemo(() => {
    if (!ebook) return [];
    return allReviews.filter((r) => r.ebookId === ebook.id);
  }, [ebook]);

  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [newRating, setNewRating] = useState<1 | 2 | 3 | 4 | 5>(5);
  const [newComment, setNewComment] = useState("");

  if (!ebook) {
    return (
      <div className="rounded-2xl border border-border bg-white p-6 text-center">
        <div className="text-sm font-semibold text-ink">E-book tidak ditemukan</div>
        <div className="mt-1 text-sm text-muted">Coba kembali ke katalog.</div>
        <div className="mt-4">
          <Link to="/katalog">
            <Button variant="secondary">Kembali</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <div className="grid gap-8 lg:grid-cols-[360px_1fr]">
        <div className="space-y-4">
          <div className="overflow-hidden rounded-2xl border border-border bg-white shadow-soft">
            <img src={ebook.coverUrl} alt={ebook.title} className="w-full object-cover" />
          </div>

          <div className="rounded-2xl border border-border bg-white p-4">
            <div className="flex flex-wrap gap-2">
              {ebook.isBestSeller ? <Badge tone="warning">Best Seller</Badge> : null}
              {ebook.isFeatured ? <Badge tone="brand">Unggulan</Badge> : null}
              {ebook.access === "OPEN" ? <Badge tone="neutral">Gratis</Badge> : null}
              {ebook.access === "MEMBERSHIP" ? (
                <Badge tone="success">
                  Membership{ebook.requiredPlan ? ` • ${ebook.requiredPlan}` : ""}
                </Badge>
              ) : null}
              {ebook.access === "PAID" ? <Badge tone="neutral">Beli satuan</Badge> : null}
            </div>

            <div className="mt-4 flex items-center justify-between gap-3">
              <div className="text-sm font-semibold text-ink">Akses</div>
              <div className={cn("text-sm font-semibold", allowed ? "text-emerald-700" : "text-muted")}>
                {allowed ? "Tersedia" : "Perlu akses"}
              </div>
            </div>

            <div className="mt-4 grid gap-2">
              {ebook.access === "PAID" ? (
                <Button
                  onClick={() => {
                    markOwned(ebook.id, ebook.pageCount);
                    navigate("/checkout");
                  }}
                >
                  <ShoppingBag size={16} />
                  Beli Sekarang • {formatIdrFromCents(ebook.priceCents)}
                </Button>
              ) : null}

              <Button
                variant={allowed ? "primary" : "secondary"}
                onClick={() => {
                  addToLibrary(ebook.id, ebook.pageCount);
                  if (allowed) navigate(`/baca/${ebook.id}`);
                  else navigate("/langganan");
                }}
              >
                <BookOpenText size={16} />
                {allowed ? "Baca Sekarang" : "Tambah ke Perpustakaan"}
              </Button>

              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="secondary"
                  onClick={() => toggleWishlist(ebook.id)}
                  className={cn(isWishlisted && "border-brand-2 bg-brand-2/10 text-brand-2")}
                >
                  <Heart size={16} className={cn(isWishlisted && "fill-current")} />
                  Wishlist
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    addToLibrary(ebook.id, ebook.pageCount);
                    navigate("/perpustakaan");
                  }}
                >
                  <Bookmark size={16} />
                  Perpustakaan
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="text-2xl font-semibold tracking-tight text-ink md:text-3xl">
                  {ebook.title}
                </div>
                <div className="mt-2 text-sm text-muted">
                  {author?.displayName ?? "—"} • {ebook.category} • {ebook.pageCount} halaman
                </div>
                <div className="mt-4 flex items-center gap-3">
                  <RatingStars rating={ebook.ratingAvg} size="md" />
                  <div className="text-sm font-semibold text-ink">{ebook.ratingAvg.toFixed(1)}</div>
                  <div className="text-sm text-muted">({ebook.ratingCount.toLocaleString("id-ID")} ulasan)</div>
                </div>
              </div>
              {ebook.tags.length ? (
                <div className="flex flex-wrap gap-2">
                  {ebook.tags.slice(0, 3).map((t) => (
                    <Badge key={t} tone="neutral">
                      {t}
                    </Badge>
                  ))}
                </div>
              ) : null}
            </div>

            <div className="mt-5 text-sm leading-relaxed text-muted">{ebook.description}</div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="text-sm font-semibold text-ink">Profil penulis</div>
            <div className="mt-4 flex items-start gap-4">
              <div className="h-14 w-14 overflow-hidden rounded-2xl bg-surface">
                {author?.avatarUrl ? (
                  <img src={author.avatarUrl} alt={author.displayName} className="h-full w-full object-cover" />
                ) : null}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold text-ink">{author?.displayName ?? "—"}</div>
                <div className="mt-1 text-sm text-muted">{author?.bio ?? ""}</div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
            <div className="flex items-end justify-between gap-4">
              <div>
                <div className="text-sm font-semibold text-ink">Preview beberapa halaman</div>
                <div className="mt-1 text-sm text-muted">
                  {allowed ? "Kamu bisa lanjut membaca di Reader." : "Preview terbatas. Upgrade untuk akses penuh."}
                </div>
              </div>
              <Link to={`/baca/${ebook.id}`}>
                <Button variant={allowed ? "primary" : "secondary"} size="sm">
                  {allowed ? "Buka Reader" : "Coba Preview"}
                </Button>
              </Link>
            </div>

            <div className="mt-5 grid gap-3">
              {ebook.previewPages.slice(0, 3).map((p, idx) => (
                <div key={idx} className="rounded-2xl border border-border bg-surface p-4">
                  <div className="text-xs font-semibold text-muted">Halaman {idx + 1}</div>
                  <div className="mt-2 whitespace-pre-wrap font-serif text-sm leading-relaxed text-ink">
                    {p}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
              <div className="text-sm font-semibold text-ink">Ulasan pembaca</div>
              <div className="mt-4 space-y-4">
                {reviews.length ? (
                  reviews.map((r) => (
                    <div key={r.id} className="rounded-2xl border border-border bg-surface p-4">
                      <div className="flex items-center justify-between gap-3">
                        <RatingStars rating={r.rating} />
                        <div className="text-xs text-muted">
                          {new Date(r.createdAtISO).toLocaleDateString("id-ID", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                          })}
                        </div>
                      </div>
                      <div className="mt-2 text-sm text-ink">{r.comment}</div>
                    </div>
                  ))
                ) : (
                  <div className="text-sm text-muted">Belum ada ulasan.</div>
                )}
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-white p-6 shadow-[0_1px_0_rgba(15,23,42,0.04)]">
              <div className="text-sm font-semibold text-ink">Tulis ulasan</div>
              <div className="mt-4 grid gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  {([1, 2, 3, 4, 5] as const).map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setNewRating(n)}
                      className={cn(
                        "rounded-full border px-3 py-1 text-xs font-semibold transition",
                        newRating === n
                          ? "border-brand-2 bg-brand-2/10 text-brand-2"
                          : "border-border bg-white text-muted hover:bg-surface"
                      )}
                    >
                      {n}★
                    </button>
                  ))}
                </div>

                <textarea
                  className="min-h-28 w-full resize-none rounded-2xl border border-border bg-white p-3 text-sm text-ink outline-none transition focus:border-brand-2 focus:ring-2 focus:ring-brand-2/15"
                  placeholder="Bagikan pendapatmu tentang buku ini…"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                />

                <Button
                  variant="secondary"
                  onClick={() => {
                    const comment = newComment.trim();
                    if (!comment) return;
                    setReviews((prev) => [
                      {
                        id: `r_${Date.now()}`,
                        ebookId: ebook.id,
                        userId: uid,
                        rating: newRating,
                        comment,
                        createdAtISO: new Date().toISOString(),
                      },
                      ...prev,
                    ]);
                    setNewComment("");
                  }}
                >
                  <Check size={16} />
                  Kirim
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-5">
            <div className="flex items-end justify-between gap-4">
              <div>
                <div className="text-lg font-semibold tracking-tight text-ink">Rekomendasi serupa</div>
                <div className="mt-1 text-sm text-muted">
                  Berdasarkan kategori dan penulis yang sama.
                </div>
              </div>
              <Link to="/katalog" className="text-sm font-semibold text-brand hover:underline">
                Kembali ke katalog
              </Link>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {similar.map((b) => {
                const a = authors.find((x) => x.id === b.authorId);
                return <BookCard key={b.id} ebook={b} authorName={a?.displayName ?? "—"} />;
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

